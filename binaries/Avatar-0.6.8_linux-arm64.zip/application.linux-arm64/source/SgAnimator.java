import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import com.badlogic.gdx.math.*; 
import com.badlogic.gdx.utils.*; 
import gwel.game.anim.*; 
import gwel.game.graphics.*; 
import gwel.game.entities.*; 
import controlP5.*; 
import java.util.Deque; 
import java.util.ArrayDeque; 
import java.util.*; 
import java.lang.reflect.Field; 
import java.lang.reflect.Constructor; 
import java.lang.reflect.InvocationTargetException; 
import java.io.FileInputStream; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SgAnimator extends PApplet {

// programme python "key-mon" pour afficher les touches du clavier

// TODO:
// éviter que les éléments d'UI sortent de la fenêtre
// Elastic function
// Option to duplicate previous AnimationCollection when new animCollection
// UV coords in polygon class
// Add a chart for every Animation to show function progression over time
// Lib : avatar.playSequencialy()

/*
  BUGS:
 * fullscreen 
 * Seule la première animation est sauvegardée
 * Can't select axe before function
 * Resize window doesn't resize UI immediately
 *
 */
















String version = "0.6.8";


MainScreen mainScreen;
LoadScreen loadScreen;
Screen welcomeScreen;
Screen helpScreen1;
Screen helpScreenEasing;
Screen currentScreen;

MyRenderer renderer;
Avatar avatar;
String baseFilename;

ComplexShape selected = null;
int selectedIndex = 0;
String[] functionsName;
PostureCollection postures;
int postureIndex = 0;
boolean animationCollectionDirty = false;
Animation animationClipboard;

boolean showUI = false;
boolean paramLocked = false;
boolean setPivot = false;
boolean playing = true;
boolean mustUpdateUI = false;
File mustLoad = null; // Change current screen to loading screen


public void settings() {
  //fullScreen();
  //size(1200, 700);
  size(800, 600);
}


public void setup() {
  surface.setResizable(true);
  surface.setTitle("Avatar5");

  mainScreen = new MainScreen();
  welcomeScreen = new WelcomeScreen();
  helpScreen1 = new HelpScreen1();
  helpScreenEasing = new HelpScreenEasing();
  currentScreen = welcomeScreen;
  
  renderer = new MyRenderer(this);

  int numFn = Animation.timeFunctions.length;
  functionsName = new String[numFn];
  for (int i=0; i<numFn; i++) {
    int idx = Animation.timeFunctions[i].getName().lastIndexOf('.');
    functionsName[i] = Animation.timeFunctions[i].getName().substring(idx+3);
  }

  setupUI();
}


public ComplexShape buildBlob() {
  // A try at a generative rigging
  int n = 10;

  ComplexShape root = new ComplexShape();
  ComplexShape parent = root;
  float x = 0;
  for (int i=0; i<n; i++) {
    ComplexShape segment = new ComplexShape();
    segment.addShape(new DrawableCircle(x, 0, 20));
    float[] verts = {x, 10, x+50, 6, x+50, -6, x, -10};
    segment.addShape(new DrawablePolygon(verts, null));
    segment.setLocalOrigin(x, 0);
    Animation[] anims = new Animation[1];
    anims[0] = new Animation(new TFSin(0.2f, 0.3f, 0f, x*0.012f), Animation.AXE_ROT);
    segment.setAnimationList(anims);
    parent.addShape(segment);
    parent = segment;
    x += 50;
  }
  return root;
}


public void select(ComplexShape part) {
  showUI = true;
  selected = part;
  updateUI();
  renderer.setSelected(part);
}


public void savePosture() {
  //HashMap<String, Animation[]> posture = new HashMap();
  Posture posture = new Posture();

  String postureName = transport.postureName.getText();
  if (postureName == null || postureName.trim().isEmpty())
    postureName = "posture" + postureIndex;
  posture.name = postureName;
  
  posture.duration = transport.animDuration.getValue();
  
  Animation[][] groups = new Animation[avatar.getPartsList().length][];
  Arrays.fill(groups, null);
  for (int i = 0; i < groups.length; i++) {
    ComplexShape part = avatar.getPartsList()[i];
    if (part.getAnimationList().length > 0)
      groups[i] = part.getAnimationList();
  }
  posture.groups = groups;

  if (postureIndex >= postures.size()) {
    postures.addPosture(posture);
  } else {
    postures.updatePosture(postureIndex, posture);
  }

  animationCollectionDirty = false;
}


public void drawKey(int x, int y, String k, float height) {
  textSize(floor(height * 0.5f));
  float margin = 0.1f * height;
  float wi = max(height - 2*margin, textWidth(k) + 10);
  float w = wi + 2*margin;
  fill(180);
  stroke(63);
  rect(x, y, w, height, 0.15f * height);
  fill(220);
  stroke(240);
  float hi = height * 0.8f;
  rect(x + margin, y + 0.8f*margin, wi, hi, 0.15f * hi);
  
  fill(0);
  text(k, x + 2*margin, y + hi - 1.5f*margin);
}


public void draw() {
  if (mustLoad != null) {
    loadScreen.setupUI(mustLoad);
    currentScreen = loadScreen;
    mustLoad = null;
  }
  currentScreen.draw();
}


public void keyPressed(KeyEvent event) { currentScreen.keyPressed(event); }
public void keyReleased(KeyEvent event) { currentScreen.keyReleased(event); }
public void mousePressed(MouseEvent event) {currentScreen.mousePressed(event); }
public void mouseReleased(MouseEvent event) {currentScreen.mouseReleased(event); }
public void mouseClicked(MouseEvent event) {currentScreen.mouseClicked(event); }
public void mouseWheel(MouseEvent event) { currentScreen.mouseWheel(event); }
public void mouseDragged(MouseEvent event) { currentScreen.mouseDragged(event); }


public abstract class Screen {
  public void draw() { }
  public void keyPressed(KeyEvent event) { }
  public void keyReleased(KeyEvent event) { }
  public void mousePressed(MouseEvent event) { }
  public void mouseReleased(MouseEvent event) { }
  public void mouseClicked(MouseEvent event) { }
  public void mouseWheel(MouseEvent event) { }
  public void mouseDragged(MouseEvent event) { }
}



public void controlEvent(ControlEvent event) throws InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException  {
  if (paramLocked)
    return;
  
  if (timeline != null)
      timeline.hide();
      
  if (event.isController()) {
    avatar.resetAnimation();
    String name = event.getName();
    float value = event.getValue();
    //println("event", name, value);
    
    if (name.equals("partslist")) {
      select(avatar.getPartsList()[PApplet.parseInt(value)]);
      selectedIndex = PApplet.parseInt(partsList.getValue());
    }
    
    else if (name.equals("posturename")) {
      // Change fullAnim name
      animationCollectionDirty = true;
    }
    
    else if (name.startsWith("function")) {
      String[] m = match(name, "function(\\d+)");
      int animNum = parseInt(m[1]);
      Class<TimeFunction> tfclass = Animation.timeFunctions[(int) event.getValue()];
      Constructor<TimeFunction> ctor = tfclass.getConstructor();
      TimeFunction tf = ctor.newInstance();
      int numberOfAnimations = selected.getAnimationList().length;
      if (animNum < numberOfAnimations) {
        // Transfer compatible parameters to new TimeFunction
        //for (TFParam param : selected.getAnimation(animNum).getFunction().getParams()) {
        //  Object payload = param.getValue();
        //  println(payload.getClass());
        //  //tf.setParam(param.name, param.getValue()); // BROKEN
        //}
        selected.getAnimation(animNum).setFunction(tf);
      } else {
        selected.addAnimation(new Animation(tf));
      }
      selected.reset();
      if (tf instanceof TFTimetable) {
        timeline = new Timeline(animNum);
        timeline.setFunction((TFTimetable) tf);
        timeline.show();
      }
      mustUpdateUI = true;
      playing = true;
      animationCollectionDirty = true;
    }
    
    else if (name.startsWith("axe")) {
      String[] m = match(name, "axe(\\d+)");
      int animNum = parseInt(m[1]);
      selected.getAnimation(animNum).setAxe((int) value);
      mustUpdateUI = true;
      playing = true;
      animationCollectionDirty = true;
    }
    
    else if (name.startsWith("animamp")) {
      String[] m = match(name, "animamp(\\d+)");
      int animNum = parseInt(m[1]);
      selected.getAnimation(animNum).setAmp(value);
      animationCollectionDirty = true;
    }
    
    else if (name.startsWith("animinv")) {
      String[] m = match(name, "animinv(\\d+)");
      int animNum = parseInt(m[1]);
      selected.getAnimation(animNum).setInv(value == 0 ? true : false);
      animationCollectionDirty = true;
    }
    
    else if (name.equals("pivotbutton")) {
      setPivot = ((Button) cp5.getController("pivotbutton")).isOn();
      avatar.resetAnimation();
      playing = false;
    }
    
    else if (name.startsWith("copybutton")) {
      String[] m = match(name, "copybutton(\\d+)");
      int animNum = parseInt(m[1]);
      animationClipboard = selected.getAnimation(animNum).copy();
      mustUpdateUI = true;
    }
    
    else if (name.startsWith("pastebutton")) {
      String[] m = match(name, "pastebutton(\\d+)");
      int animNum = parseInt(m[1]);
      if (animationClipboard != null) {
        selected.reset();
        if (animNum < selected.getAnimationList().length) {
          selected.setAnimation(animNum, animationClipboard.copy());
        } else {
          selected.addAnimation(animationClipboard.copy());
        }
        mustUpdateUI = true;
        animationCollectionDirty = true;
      }
    }
    
    else if (name.startsWith("deletebutton")) {
      String[] m = match(name, "deletebutton(\\d+)");
      int animNum = parseInt(m[1]);
      selected.reset(); // So transform matrix is set to identity
      selected.removeAnimation(animNum);
      mustUpdateUI = true;
      animationCollectionDirty = true;
    }
    
    else if (name.startsWith("swapup")) {
      String[] m = match(name, "swapup(\\d+)");
      int animNum = parseInt(m[1]);
      Animation moveup = selected.getAnimation(animNum);
      selected.setAnimation(animNum, selected.getAnimation(animNum-1));
      selected.setAnimation(animNum-1, moveup);
      //updateUI();
      keepsOpenAnimNum = animNum-1;
      mustUpdateUI = true;
      animationCollectionDirty = true;
    }
    
    else if (name.startsWith("swapdown")) {
      String[] m = match(name, "swapdown(\\d+)");
      int animNum = parseInt(m[1]);
      Animation moveup = selected.getAnimation(animNum+1);
      selected.setAnimation(animNum+1, selected.getAnimation(animNum));
      selected.setAnimation(animNum, moveup);
      //updateUI();
      keepsOpenAnimNum = animNum+1;
      mustUpdateUI = true;
      animationCollectionDirty = true;
    }
    
    else if (name.startsWith("showtimeline")) {
      String[] m = match(name, "([a-z]+)(\\d+)");
      if (m != null) {
        int animNum = parseInt(m[2]);
        timeline.setFunction((TFTimetable) selected.getAnimation(animNum).getFunction());
      }
      timeline.show();
    }
    
    else if (name.startsWith("tl")) {
      // Timeline specific parameters
      String[] m = match(name, "([a-z]+)(\\d+)");
      if (m != null) {
        if (m[1].equals("tlnumsteps")) {
          timeline.updateTable();
        }
        else if (m[1].equals("tlslider")) {
          timeline.setTableValue(Integer.parseInt(m[2]), value);
        }
        else if (m[1].equals("tllshift")) {
          timeline.lshift();
        }
        else if (m[1].equals("tlrshift")) {
          timeline.rshift();
        }
      }
      timeline.show();
      animationCollectionDirty = true;
    }
    
    else {
      String[] m = match(name, "([a-z]+)(\\d+)");
      if (m != null) {
        String paramName = m[1];
        int animNum = parseInt(m[2]);
        TimeFunction fn = selected.getAnimation(animNum).getFunction();
        if (paramName.equals("easing")) {
          // Send value as a string (name of the easing function)
          int idx = floor(value);
          fn.setParam(paramName, Animation.interpolationNamesSimp[idx]);
        } else {
          fn.setParam(paramName, value);
        }
        playing = true;
        animationCollectionDirty = true;
        if (timeline != null && timeline.getFunction() == fn)
          timeline.show();
      }
    }
  }
}




public void inputFileSelected(File selection) throws IOException { 
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    println("User selected " + selection.getAbsolutePath());
    String filename = selection.getAbsolutePath();
    if (filename.endsWith("svg")) {
      ComplexShape shape = ComplexShape.fromPShape(loadShape(filename));
      if (shape == null) {
        println("Could not load SVG file");
        return;
      }
      
      selectedIndex = 0;
      selected = null;
      // Go down the complexShape tree if the root is empty
      while (shape.getShapes().size() == 1 && shape.getChildren().size() == 1)
        shape = (ComplexShape) shape.getShapes().get(0);
      
      postures = new PostureCollection();
      avatar = new Avatar();
      avatar.setShape(shape);
      partsList.setItems(avatar.getPartsNamePre());
      baseFilename = filename.substring(0, filename.length()-4);
      
      
      currentScreen = mainScreen;
      transport.postureName.setText("posture0");
      mainScreen.resetView();
      showUI();
      accordion.hide();
      
    /*} else if (filename.endsWith("tdat")) {
      rootShape = loadGeometry(selection);
      File animFile = new File(filename.replace(".tdat", ".json"));
      if (animFile.exists()) {
        JSONObject rootElement = loadJSONObject(selection);
        loadAnimation(rootElement.getJSONArray("animation"));
      }*/
    } else if (filename.endsWith("json")) {
      mustLoad = selection;
    } else {
      println("Bad filename");
    }
  }
}


public void outputFileSelected(File selection) {
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    if (avatar != null) {
      if (animationCollectionDirty)
        savePosture();
      
      String filename = selection.getAbsolutePath();
      if (!filename.toLowerCase().endsWith(".json"))
        filename = filename.concat(".json");
      
      avatar.postures = postures;
      avatar.saveFile(filename);
    }
  }
}
public class HelpScreen1 extends Screen {
  
  @Override
  public void draw() {
    background(255);
    fill(63);
    textSize(20);
    /*text("CTRL+o\n"+
      "CTRL+s\n"+
      "Up/Down\n"+
      "p\n"+
      "r\n"+
      "d\n"+
      "h\n"+
      "w\n"+
      "right click\n"+
      "MAJ + right drag/mouseWheel\n"+
      "Escape\n", width/4, height/4);*/
    int w = (width/2) - 120;
    int h = (height/4) - 2;
    int hStep = 30;
    int keySize = 24;
    drawKey(w, h - 2*keySize/3, "Ctrl", keySize);
    textSize(20);
    text("+", w + 40, h);
    drawKey(w + 60, h - 2*keySize/3, "O", keySize);
    h += hStep;
    drawKey(w, h - 2*keySize/3, "Ctrl", keySize);
    textSize(20);
    text("+", w + 40, h);
    drawKey(w + 60, h - 2*keySize/3, "S", keySize);
    h += 2*hStep;
    w = (width/2) - 60;
    drawKey(w, h - 2*keySize/3, "P", keySize);
    h += hStep;
    drawKey(w, h - 2*keySize/3, "R", keySize);
    h += hStep;
    drawKey(w, h - 2*keySize/3, "D", keySize);
    h += hStep;
    drawKey(w, h - 2*keySize/3, "H", keySize);
    h += hStep;
    drawKey(w, h - 2*keySize/3, "W", keySize);
    textSize(20);
    text("Open file (svg or json)\n"+
      "Save json file\n"+
      "Select next/previous shape group\n"+
      "Play/Pause animation\n"+
      "Reset animation\n"+
      "Show/Hide UI\n"+
      "Help screen\n"+
      "Wireframe\n"+
      "Place pivot\n"+
      "Translate/scale geometry\n"+
      "Exit program\n", width/2, height/4);
    text("Ver. "+version, width-110, height-20);
  }
  
  public void keyPressed(KeyEvent event) {
    if (key == 'h') {
      currentScreen = helpScreenEasing;
    }
  }
  
  public @Override
  void mouseClicked(MouseEvent event) {
    currentScreen = helpScreenEasing;
  }
}
public class HelpScreenEasing extends Screen {
  private int frameWidth = 120;
  private int frameHeight = 90;
  private int spacing = 8;
  private int margin = width/8;
  private PGraphics[] frames;


  HelpScreenEasing() {
    frames = new PGraphics[Animation.interpolationNamesSimp.length];
    int i = 0;
    for (String interpolationName : Animation.interpolationNamesSimp) {
      Interpolation fn = Animation.getInterpolation(interpolationName);
      frames[i++] = createInterpolationFrame(frameWidth, frameHeight, fn, interpolationName);
    }
  }


  public PGraphics createInterpolationFrame(int w, int h, Interpolation fn, String name) {
    PGraphics pg = createGraphics(w, h);
    pg.beginDraw();
    pg.background(0xffFFC500);
    float prev = h * fn.apply(0f);
    float val;
    float penX;
    float stepX = 2f;
    pg.stroke(0);
    for (penX=stepX; penX<w; penX+=stepX) {
      val = h * fn.apply(penX/w);
      pg.line(penX-stepX, h-prev, penX, h-val);
      prev = val;
    }
    val = h * fn.apply(1f);
    pg.line(penX-stepX, h-prev, w, h-val);
    pg.fill(0, 127);
    pg.text(name, w-textWidth(name)-4, h-4);
    pg.endDraw();
    return pg;
  }


  @Override
  public void draw() {
    background(255);
    fill(127);
    textSize(32);
    int offset = floor(textWidth("Easing functions"));
    text("Easing functions", (width/2)-offset/2, -20+height/6);

    int posX = margin;
    int posY = height/5;
    for (PGraphics frame : frames) {
      image(frame, posX, posY);
      posX += frameWidth + spacing;
      if (posX + frameWidth + spacing > width-margin) {
        posX = margin;
        posY += frameHeight + spacing;
      }
    }
  }


  public @Override
  void keyPressed(KeyEvent event) {
    if (avatar != null)
      showUI();
    currentScreen = mainScreen;
  }
  
  public @Override
  void mouseClicked(MouseEvent event) {
    if (avatar != null)
      showUI();
    currentScreen = mainScreen;
  }
}



public class LoadScreen extends Screen {
  private PImage backgroundImage;
  Group loadGroup;
  Toggle geomToggle, animToggle;
  int groupWidth = 180;
  int groupHeight = 180;
  String filename;
  File selection;
  boolean mustDestroy = false;
  
  public LoadScreen() {
    doBackground();
  }

  public void setupUI(File selection) {
    this.selection = selection;
    filename = selection.getAbsolutePath();

    hideUI();

    paramLocked = true;
    loadGroup = new Group(cp5, "loadfilegroup")
      .setWidth(groupWidth)
      .setBackgroundHeight(groupHeight)
      .setPosition((width/2)-(groupWidth/2), (height/2)-(groupHeight/2))
      .setBackgroundColor(color(0, 100))
      .hideBar()
      ;
    
    cp5.addTextlabel("filenamelabel")
      .setPosition(4, 10)
      .setFont(defaultFont)
      .setText(selection.getName())
      .setGroup(loadGroup)
      ;

    geomToggle = cp5.addToggle("loadgeometrytoggle")
      .setLabelVisible(false)
      .setPosition(groupWidth-56, 60)
      .setSize(20, 20)
      .setValue(1.0f)
      .setGroup(loadGroup)
      ;
    cp5.addTextlabel("loadgeometrylabel")
      .setPosition(32, 60 + 3)
      .setFont(defaultFont)
      .setText("Geometry")
      .setGroup(loadGroup)
      ;

    animToggle = cp5.addToggle("loadanimationtoggle")
      .setLabelVisible(false)
      .setPosition(groupWidth-56, 90)
      .setSize(20, 20)
      .setValue(1.0f)
      .setGroup(loadGroup)
      ;
    cp5.addTextlabel("loadanimationlabel")
      .setPosition(32, 90 + 3)
      .setFont(defaultFont)
      .setText("Animations")
      .setGroup(loadGroup)
      ;

    int okWidth = 50;
    cp5.addButton("loadokbutton")
      .removeCallback()
      .setWidth(okWidth)
      .setPosition((groupWidth/2)-(okWidth/2), groupHeight-34)
      .setLabel("Ok")
      .setGroup(loadGroup)
      .plugTo(this, "okFunction")
      ;
    paramLocked = false;
  }


  public void doBackground() {
    backgroundImage = createImage(width, height, RGB);
    loadPixels();
    arrayCopy(pixels, backgroundImage.pixels);
    backgroundImage.updatePixels();
    backgroundImage.filter(GRAY);
    backgroundImage.filter(BLUR, 3);
  }


  public void okFunction() {
    if (paramLocked == true)
      return;

    loadAvatarFile(selection);

    selectedIndex = 0;
    selected = null;
    partsList.setItems(avatar.getPartsNamePre());
    baseFilename = filename.substring(0, filename.length()-5);
    showUI();
    accordion.hide();

    mustDestroy = true;
  }


  private void loadAvatarFile(File file) {
    boolean loadGeom = geomToggle.getValue() == 1.0f;
    boolean loadAnim = animToggle.getValue() == 1.0f;
    
    Avatar newAvatar = Avatar.fromFile(file);
    if (newAvatar == null)
      return;
    
    if (loadGeom) {
      avatar = newAvatar;
      mainScreen.resetView();
    }
    
    // AnimationCollection is kept separated for simplicity
    // rather than storing and retrieving it from the Avatar class
    postureIndex = 0;
    if (loadAnim) {
      postures = newAvatar.postures;
      if (postures.size() > 0) {
        avatar.postures = postures;
        transport.postureName.setText(postures.getPosture(0).name);
        transport.animDuration.setValue(postures.getPosture(0).duration);
        transport.prevAnimDuration = postures.getPosture(0).duration;
        avatar.loadPosture(0);
      }
    } else {
      postures = new PostureCollection();
    }
    
    surface.setTitle("Avatar5 - " + filename);
  }


  @Override
  public void draw() {
    if (backgroundImage != null) {
      image(backgroundImage, 0, 0);
    } else  {
      background(255);
    }

    if (mustDestroy) {
      loadGroup.remove();
      currentScreen = mainScreen;
    }
  }
}
public class MainScreen extends Screen {
  PImage selectpart;
  Affine2 transform;
  Affine2 hardTransform;
  TimeFunction selectpartAnim;
  private boolean transportMoving = false;
  
  private float framerate = frameRate;
  private int recordFrames = 0;


  public MainScreen() {
    selectpart = loadImage("selectpart.png");
    selectpartAnim = new TFEaseFromTo(60, 0, 0.66f, 0.66f, "bounceOut", false, true);
    transform = new Affine2().setToTranslation(width/2, height/2);
    hardTransform = new Affine2();
  }


  public void resetView() {
    transform.setToTranslation(width/2, height/2);
  }
  
  
  public void startRecording() {
    recordFrames = floor(transport.animDuration.getValue() * framerate);
    avatar.resetAnimation();
    renderer.setBackgroundColor(1, 1, 1, 1);
    renderer.startRecording();
  }
  
  public void stopRecording() {
    renderer.stopRecording();
  }


  public void draw() {
    if (avatar == null) {
      hideUI();
      currentScreen = welcomeScreen;
      return;
    }

    background(255);

    renderer.pushMatrix(transform);
    if (playing)
      avatar.update(1f/framerate);
    avatar.draw(renderer);
    
    if (renderer.isRecording() && playing) {
      renderer.flush();
      if (recordFrames > 0) {
        recordFrames--;
        if (recordFrames == 0) {
          stopRecording();
          transport.buttonRec.setOff();
        }
      }
    } else {
      avatar.drawSelectedOnly(renderer);
    }

    if (showUI) {
      if (selected != null) {
        if (!hardTransform.isIdt()) {
          renderer.pushMatrix(hardTransform);
          selected.setColorMod(1f, 1f, 1f, 0.4f);
          selected.draw(renderer);
          selected.setColorMod(1f, 1f, 1f, 1f);
          renderer.drawPivot();
          renderer.popMatrix();
        } else {
          renderer.drawPivot();
        }
      } else {
        selectpartAnim.update(1/framerate);
        if (selectpart != null)
          image(selectpart, partsList.getPosition()[0] + partsList.getWidth() + 4 + selectpartAnim.getValue(), partsList.getPosition()[1] + selectpartAnim.getValue()/3);
      }
      renderer.drawMarker(0, 0);
      renderer.drawAxes();
    }
    renderer.popMatrix();
    
    if (playing == false && (frameCount>>5)%2 == 0) {
      fill(255, 0, 0, 127);
      textSize(32);
      text("PAUSED", -60+width/2, height-80);
    }
    if (timeline != null) {
      timeline.highlightSliders();
    }

    if (setPivot) {
      fill(255, 0, 0);
      noStroke();
      ellipse(mouseX, mouseY, 8, 8);
    }

    if (mustUpdateUI == true && selected != null) {
      updateUI();
      mustUpdateUI = false;
    }
  }
  

  public void keyPressed(KeyEvent event) {
    if (avatar != null && key == CODED) {
      if (keyCode == UP) {  // Select next part
        selectedIndex = (selectedIndex-1);
        if (selectedIndex < 0)
          selectedIndex += avatar.getPartsList().length;
        partsList.setValue(selectedIndex);
      } else if (keyCode == DOWN) {  // Select previous part
        selectedIndex = (selectedIndex+1) % avatar.getPartsList().length;
        partsList.setValue(selectedIndex);
      } else if (keyCode == SHIFT && selected != null && !isNumberboxActive) {
        playing = false;
        avatar.resetAnimation();
      }
    } else if (!transport.postureName.isActive() && !isNumberboxActive) {
      switch (key) {
      case 'p':  // Play/Pause animation
        if (avatar != null)
          playing = !playing;
        break;
      case 'r':  // Reset animation
        if (avatar != null)
          avatar.resetAnimation();
        if (selected != null) mustUpdateUI = true;
        break;
      case 'd':  // Show/Hide UI
        if (avatar != null) {
          if (showUI) {
            hideUI();
            if (timeline != null)
              timeline.hide();
          } else {
            showUI();
          }
        }
        break;
      case 't':  // Physics scren
        hideUI();
        currentScreen = new PhysicsScreen(transform);
        break;
      case 'h':  // Help screens
        hideUI();
        currentScreen = helpScreen1;
        break;
      case 'w':  // Wireframe
        renderer.toggleWireframe();
        break;
      case 15:  // CTRL+o, load a new file
        selectInput("Select a file", "inputFileSelected");
        loadScreen = new LoadScreen();
        break;
      case 19: // CTRL+s, save
        selectOutput("Select a file", "outputFileSelected");
        break;
      }
    }
  }


  public void keyReleased(KeyEvent event) {
    if (key == CODED && keyCode == SHIFT && selected != null && !isNumberboxActive) {
      selected.hardTransform(hardTransform);
      // Transform physics shell if necessary
      if (selected == avatar.shape) {
        for (Shape shape : avatar.physicsShapes)
          shape.hardTransform(hardTransform);
      }
      hardTransform.idt();
      playing = true;
      mustUpdateUI = true;
    }
  }


  public void mouseWheel(MouseEvent event) {
    pivotButton.hide();
    if (!partsList.isInside()) {
      float z = pow(1.1f, -event.getCount());
      Affine2 unproject = new Affine2(transform).inv();
      Vector2 point = new Vector2(mouseX, mouseY);
      unproject.applyTo(point);
      if (keyPressed && keyCode == SHIFT && selected != null) {
        // scale translation by the zoom factor
        point = selected.getLocalOrigin();
        z = 1 + (z-1) * 0.1f;
        hardTransform.translate(point.x, point.y).scale(z, z).translate(-point.x, -point.y);
      } else {
        // scale translation by the zoom factor
        transform.translate(point.x, point.y).scale(z, z).translate(-point.x, -point.y);
      }
    }
  }
  
  
  public void mousePressed(MouseEvent event) {
    if (transport.contains(mouseX, mouseY)) {
      transportMoving = true;
    }
  }
  
  
  public void mouseReleased(MouseEvent event) {
    transportMoving = false;
  }


  public void mouseClicked(MouseEvent event) {
    if (event.getButton() == LEFT) {
      if (setPivot && !cp5.getController("pivotbutton").isInside()) {
        Vector2 point = new Vector2(mouseX, mouseY);
        Affine2 t = new Affine2(transform).inv();
        t.applyTo(point);
        selected.setLocalOrigin(point.x, point.y);
        ((Button) cp5.getController("pivotbutton")).setOff();
        playing = true;
      }
      pivotButton.hide();
    } else {
      // RIGHT CLICK opens context menu (pivot button)
      if (selected != null) {
        pivotButton.setPosition(mouseX, mouseY);
        pivotButton.show();
      }
    }
  }


  public void mouseDragged(MouseEvent event) {
    pivotButton.hide();
    if (event.getButton() == RIGHT) {
      int dx = mouseX-pmouseX;
      int dy = mouseY-pmouseY;
      if (keyPressed && keyCode == SHIFT && selected != null) {
        // scale translation by the zoom factor
        hardTransform.translate(dx/transform.m00, dy/transform.m11);
      } else {
        // scale translation by the zoom factor
        transform.translate(dx/transform.m00, dy/transform.m11);
      }
    } else if (transportMoving) {
      transport.move(mouseX-pmouseX, mouseY-pmouseY);
    }
  }
}
public class PhysicsScreen extends Screen {
  private final Affine2 transform;
  private int colorSelected = color(255, 127, 0);

  private ArrayList<Shape> clicked = new ArrayList();
  private Shape selectedShape;
  private int selectedHandle = -1;
  private boolean computeConvexHull = false;
  private final Affine2 unproject = new Affine2();
  private final Vector2 tmpVec = new Vector2();
  private final ConvexHull convexHull;

  private int MAX_POINTS = 8;
  private float HANDLE_RADIUS = 10;


  public PhysicsScreen(Affine2 transform) {
    this.transform = transform;
    unproject.set(transform).inv();
    convexHull = new ConvexHull();
    avatar.resetAnimation();
  }


  public void draw() {
    background(240);

    renderer.pushMatrix(transform);
    avatar.draw(renderer);
    renderer.popMatrix();

    for (Shape shape : avatar.physicsShapes)
      drawShape(shape);

    if (selectedHandle >= 0) {
      // Draw selected handle
      stroke(colorSelected);
      strokeWeight(2);
      if (selectedShape.getClass() == DrawablePolygon.class) {
        float[] vertices = ((DrawablePolygon) selectedShape).getVertices();
        tmpVec.set(vertices[selectedHandle], vertices[selectedHandle + 1]);
        transform.applyTo(tmpVec);
        circle(tmpVec.x, tmpVec.y, HANDLE_RADIUS);
      } else if (selectedShape.getClass() == DrawableCircle.class) {
        DrawableCircle c = (DrawableCircle) selectedShape;
        tmpVec.set(c.getCenter());
        transform.applyTo(tmpVec);
        noFill();
        circle(tmpVec.x, tmpVec.y, 2 * c.getRadius() * transform.m00);
      }
    }

    strokeWeight(0.5f);
    drawKey(16, 20, "P", 28);
    text("create a Polygon shape", 100, 20+18);
    drawKey(16, 54, "MAJ", 28);
    text("+Click  add a point to selected polygon", 60, 54+18);
    drawKey(16, 88, "C", 28);
    text("create a Circle shape", 100, 88+18);
    drawKey(16, 122, "Suppr", 28);
    text("Delete selected shape", 100, 122+18);
    drawKey(16, 156, "Q", 28);
    text("Quit physics mode", 100, 156+18);
  }


  private void computeConvexPolygon(DrawablePolygon polygon) {
    float[] vertices = polygon.getVertices();
    FloatArray tmpArray = convexHull.computePolygon(vertices, false);
    float[] newVertices = new float[tmpArray.size-2];
    System.arraycopy(tmpArray.items, 0, newVertices, 0, newVertices.length);
    polygon.setVertices(newVertices);
  }


  public int getHandleIndex(Shape shape, float posX, float posY) {
    if (shape.getClass() == DrawablePolygon.class) {
      float[] vertices = ((DrawablePolygon) shape).getVertices();
      for (int i = 0; i < vertices.length; i += 2) {
        if (Vector2.dst(vertices[i], vertices[i+1], posX, posY) < HANDLE_RADIUS / transform.m00)
          return i;
      }
    } else if (shape.getClass() == DrawableCircle.class) {
      DrawableCircle c = (DrawableCircle) shape;
      float dist = Vector2.dst(posX, posY, c.getCenter().x, c.getCenter().y);
      if (abs(c.getRadius() - dist) < 0.5f * HANDLE_RADIUS / transform.m00)
        return 0;
    }
    return -1;
  }


  public void drawShape(Shape shape) {
    strokeWeight(1);
    if (shape == selectedShape) {
      stroke(colorSelected);
      fill(colorSelected, 61);
    } else {
      stroke(80);
      fill(255, 63);
    }

    if (shape.getClass() == DrawablePolygon.class) {
      float[] vertices = ((DrawablePolygon) shape).getVertices();
      beginShape();
      for (int i = 0; i < vertices.length; i += 2) {
        tmpVec.set(vertices[i], vertices[i+1]);
        transform.applyTo(tmpVec);
        vertex(tmpVec.x, tmpVec.y);
      }
      endShape(CLOSE);

      if (shape == selectedShape) {
        strokeWeight(4);
        for (int i = 0; i < vertices.length; i += 2) {
          tmpVec.set(vertices[i], vertices[i+1]);
          transform.applyTo(tmpVec);
          point(tmpVec.x, tmpVec.y);
        }
      }
    } else if (shape.getClass() == DrawableCircle.class) {
      DrawableCircle c = (DrawableCircle) shape;
      tmpVec.set(c.getCenter());
      transform.applyTo(tmpVec);
      circle(tmpVec.x, tmpVec.y, 2 * c.getRadius() * transform.m00);
      if (shape == selectedShape) {
        strokeWeight(4);
        point(tmpVec.x, tmpVec.y);
      }
    }
  }


  public void keyPressed(KeyEvent event) {
    tmpVec.set(mouseX, mouseY);
    unproject.applyTo(tmpVec);

    switch (key) {
    case 'q':
      showUI();
      currentScreen = mainScreen;
      break;
    case 'p':
      // New polygon shape
      float r = 40 / transform.m00;
      float[] vertices = new float[] {-r, +r, +r, +r, +r, -r, -r, -r};
      DrawablePolygon polygon = new DrawablePolygon();
      polygon.setVertices(vertices);
      polygon.hardTransform(new Affine2().setToTranslation(tmpVec.x, tmpVec.y));
      avatar.physicsShapes.add(polygon);
      selectedShape = polygon;
      break;
    case 'c':
      // New circle shape
      r = 40 / transform.m00;
      DrawableCircle circle = new DrawableCircle(tmpVec.x, tmpVec.y, r);
      avatar.physicsShapes.add(circle);
      selectedShape = circle;
      break;
    case 127:  // Suppr
      avatar.physicsShapes.remove(selectedShape);
      break;
    }
  }

  public void mousePressed(MouseEvent event) {
    tmpVec.set(mouseX, mouseY);
    unproject.applyTo(tmpVec);

    // Check if cursor is above a handle from the selected shape
    if (selectedShape != null) {
      selectedHandle = getHandleIndex(selectedShape, tmpVec.x, tmpVec.y);
      if (selectedHandle >= 0)
        return;

      // Maj key is pressed, add new point to selected Polygon
      if (keyPressed && keyCode == 16
        && selectedShape.getClass() == DrawablePolygon.class
        && !selectedShape.contains(tmpVec.x, tmpVec.y)) {
        DrawablePolygon polygon = (DrawablePolygon) selectedShape;
        float[] vertices = polygon.getVertices();
        if (vertices.length < 2 * MAX_POINTS) {
          float[] newVertices = new float[vertices.length + 2];
          System.arraycopy(vertices, 0, newVertices, 0, vertices.length);
          newVertices[vertices.length] = tmpVec.x;
          newVertices[vertices.length + 1] = tmpVec.y;
          polygon.setVertices(newVertices);
          computeConvexPolygon(polygon);
        }
        return;
      }
    }

    // List all shapes pointed by the mouse click
    clicked.clear();
    for (Shape shape : avatar.physicsShapes) {
      if (shape.contains(tmpVec.x, tmpVec.y))
        clicked.add(shape);
    }

    if (clicked.isEmpty()) {
      selectedShape = null;
    } else if (clicked.size() == 1) {
      selectedShape = clicked.get(0);
      // put the selected shape back on top
    }
  }


  public void mouseClicked(MouseEvent event) {
    if (clicked.size() > 0) {
      selectedShape = clicked.get(0);
      avatar.physicsShapes.remove(selectedShape);
      avatar.physicsShapes.add(selectedShape);
    }
  }


  public void mouseDragged(MouseEvent event) {
    float dx = (mouseX - pmouseX) / transform.m00;
    float dy = (mouseY - pmouseY) / transform.m00;

    if (event.getButton() == RIGHT) {
      // scale translation by the zoom factor
      transform.translate(dx, dy);
      unproject.set(transform).inv();
      return;
    }

    // Move handle
    if (selectedHandle >= 0) {
      if (selectedShape.getClass() == DrawablePolygon.class) {
        float[] vertices = ((DrawablePolygon) selectedShape).getVertices();
        vertices[selectedHandle] += dx;
        vertices[selectedHandle + 1] += dy;
        computeConvexHull = true;
      } else if (selectedShape.getClass() == DrawableCircle.class) {
        tmpVec.set(mouseX, mouseY);
        unproject.applyTo(tmpVec);
        DrawableCircle c = (DrawableCircle) selectedShape;
        float dist = Vector2.dst(tmpVec.x, tmpVec.y, c.getCenter().x, c.getCenter().y);
        c.setRadius(dist);
      }
      return;
    }

    // Translate whole shape
    if (selectedShape != null) {
      Affine2 translation = new Affine2().setToTranslation(dx, dy);
      if (selectedShape.getClass() == DrawablePolygon.class) {
        ((DrawablePolygon) selectedShape).hardTransform(translation);
      } else if (selectedShape.getClass() == DrawableCircle.class) {
        DrawableCircle circle = (DrawableCircle) selectedShape;
        circle.hardTransform(translation);
      }
    }
  }


  public void mouseReleased(MouseEvent event) {
    if (computeConvexHull) {
      computeConvexPolygon((DrawablePolygon) selectedShape);
      computeConvexHull = false;
      selectedHandle = -1;
    }
  }


  public void mouseWheel(MouseEvent event) {
    float z = pow(1.1f, -event.getCount());
    tmpVec.set(mouseX, mouseY);
    unproject.applyTo(tmpVec);

    // scale translation by the zoom factor
    transform.translate(tmpVec.x, tmpVec.y).scale(z, z).translate(-tmpVec.x, -tmpVec.y);
    unproject.set(transform).inv();
  }
}
public final PFont BitFontStandard58 = new BitFont( CP.decodeBase64( BitFont.standard58base64 ) );


class Timeline {
  private int spacing = 2;
  private int sliderSpacing = 3;
  private int sliderHeight = 120;
  private int barHeight = 12;
  private int groupHeight = sliderHeight + 40;
  private int groupWidth = 360;
  private int colorBackground = 0xff003652;
  private int colorActiveStep = 0xff00709B;
  private int colorSelected = 0xff9B7900;
  private int colorSelectedActive = 0xffFFC905;
  private int[][] colorMatrix = new int[][] {{colorBackground, colorActiveStep}, {colorSelected, colorSelectedActive}};
  Group group;
  Numberbox numSteps;
  Numberbox duration;
  Button lshift, rshift;
  Toggle loop, smoothend;
  ScrollableList easing;
  TFTimetable fn;

  Slider[] sliders;
  int selectedSlider = 0;
  int animNum;


  Timeline(int animNum) {
    paramLocked = true;

    this.animNum = animNum;

    group = cp5.addGroup("timeline")
      .setPosition(width-accordion.getWidth()-groupWidth-2*margin, margin+barHeight+1)
      .setWidth(groupWidth)
      //.hideBar()
      .setBarHeight(barHeight)
      .setBackgroundHeight(groupHeight)
      .setBackgroundColor(color(0, 100))
      ;

    numSteps = cp5.addNumberbox("tlnumsteps"+animNum)
      .setLabel("Num steps")
      .setPosition(spacing, spacing)
      .setSize(60, 20)
      .setRange(4, 32)
      .setDirection(Controller.HORIZONTAL)
      .setGroup(group)
      ;

    duration = new NumberboxInput(cp5, "duration"+animNum)
      .setLabel("duration")
      .setPosition(numSteps.getPosition()[0]+numSteps.getWidth()+spacing, spacing)
      .setSize(60, 20)
      .setRange(0.5f, 120)
      .setMultiplier(0.05f)
      .setDirection(Controller.HORIZONTAL)
      .setGroup(group)
      ;

    cp5.addScrollableList("tleasing"+animNum)
      .setLabel("easing")
      .setPosition(duration.getPosition()[0]+duration.getWidth()+spacing, spacing)
      .setWidth(80)
      .setBarHeight(20)
      //.setItemHeight(barHeight)
      .onEnter(toFront)
      .onLeave(close)
      .addItems(Animation.interpolationNamesSimp)
      .setGroup(group)
      .close()
      ;

    lshift = cp5.addButton("tllshift"+animNum)
      .setLabel("<<")
      .setPosition(220, spacing)
      .setSize(20, 20)
      .setGroup(group)
      ;

    cp5.addTextlabel("shiftlabel"+animNum)
      .setPosition(lshift.getPosition()[0]+6, spacing+24)
      .setFont(BitFontStandard58)
      .setText("SHIFT")
      .setGroup(group)
      ;

    rshift = cp5.addButton("tlrshift"+animNum)
      .setLabel(">>")
      .setPosition(lshift.getPosition()[0]+lshift.getWidth()+spacing, spacing)
      .setSize(20, 20)
      .setGroup(group)
      ;

    smoothend = cp5.addToggle("smoothend"+animNum)
      .setLabelVisible(false)
      .setPosition(280, spacing)
      .setSize(20, 20)
      .setGroup(group)
      ;
    cp5.addTextlabel("smoothendlabel"+animNum)
      .setPosition(smoothend.getPosition()[0]-15, spacing+24)
      .setText("SMOOTHEND")
      .setFont(BitFontStandard58)
      .setGroup(group)
      ;

    loop = cp5.addToggle("loop"+animNum)
      .setLabelVisible(false)
      .setPosition(330, spacing)
      .setSize(20, 20)
      .setGroup(group)
      ;
    cp5.addTextlabel("looplabel"+animNum)
      .setPosition(loop.getPosition()[0]-2, spacing+24)
      .setFont(BitFontStandard58)
      .setText("LOOP")
      .setGroup(group)
      ;


    sliders = new Slider[32];
    for (int i=0; i<32; i++) {
      sliders[i] = new TimelineSlider(cp5, "tlslider"+i)
        .setGroup(group)
        .setVisible(false)
        ;
    }

    paramLocked = false;
  }


  public void setFunction(TFTimetable fn) {
    this.fn = fn;
    update();
  }

  public TimeFunction getFunction() { 
    return fn;
  }


  public int getAnimNum() { 
    return animNum;
  }


  public void updateTable() {
    int size = (int) numSteps.getValue();
    float[] array = new float[size];
    for (int i=0; i<size; i++) {
      array[i] = sliders[i].getValue();
    }
    fn.setTable(array);
    update();
  }


  public void setTableValue(int idx, float value) {
    fn.setTableValue(idx, value);
    selectedSlider = idx;
  }

  public void hide() {
    group.hide();
  }

  public void show() {
    group.open().show();
  }


  public void update() {
    // Update all controllers according to the function parameters
    paramLocked = true;

    numSteps.setValue(fn.getTable().length);
    duration.setValue((float) fn.getParam("duration").getValue());
    //easing.setValue((int) fn.getParam("easing").getValue());
    loop.setValue((boolean) fn.getParam("loop").getValue());
    smoothend.setValue((boolean) fn.getParam("smoothend").getValue());

    int numSliders = fn.getTable().length;
    float sliderWidthFloat = ((float) groupWidth - sliderSpacing*(numSliders-1)) / numSliders;
    int sliderMinWidth = floor(sliderWidthFloat);
    int sliderWidth;
    float widthRemains = sliderWidthFloat - sliderMinWidth;
    float widthRemainsCumul = 0f;
    float posX = 0f;
    for (int i=0; i<32; i++) {
      widthRemainsCumul += widthRemains;
      sliderWidth = sliderMinWidth+floor(widthRemainsCumul);
      sliders[i].setPosition(posX, 40)
        .setSize(sliderWidth, sliderHeight)
        .setVisible(i<numSliders)
        .setValue(i<numSliders ? fn.getTable()[i] : 0f)
        ;

      posX += sliderWidth+sliderSpacing;
      if (floor(widthRemainsCumul) > 0)
        widthRemainsCumul -= floor(widthRemainsCumul);
    }

    paramLocked = false;
  }

  public void highlightSliders() {
    int[] step = fn.getActiveStep();
    int n = (int) numSteps.getValue();
    int selected;
    int active;
    for (int i=0; i<n; i++) {
      selected = i==selectedSlider || i==selectedSlider+1 ? 1 : 0;
      active = i==step[0] || i==step[1] ? 1 : 0;
      sliders[i].setColorBackground(colorMatrix[selected][active])
        .setColorForeground(active==1 ? 0xff08a2cf : 0xff00698c);
    }
  }

  public void lshift() {
    int n = (int) numSteps.getValue();
    float first = sliders[0].getValue();
    for (int i=0; i<n-1; i++)
      sliders[i].setValue(sliders[i+1].getValue());
    sliders[n-1].setValue(first);
    updateTable();
  }

  public void rshift() {
    int n = (int) numSteps.getValue();
    float last = sliders[n-1].getValue();
    for (int i=n-1; i>0; i--)
      sliders[i].setValue(sliders[i-1].getValue());
    sliders[0].setValue(last);
    updateTable();
  }


  class TimelineSlider extends Slider {
    public TimelineSlider(ControlP5 theControlP5, String theName) {
      super(theControlP5, theName);
      setRange(-1, 1);
      setSliderMode(Slider.FLEXIBLE);
      setHandleSize(5);
      setNumberOfTickMarks(3);
      snapToTickMarks(false);
      setLabelVisible(false);
    }

    @Override
      protected void onMove( ) {
      if (mousePressed) {
        float f = _myMin + (-(_myControlWindow.getPointer().getY() - (y(_myParent.getAbsolutePosition()) + y(position)) - getHeight())) * _myUnit;
        setValue( PApplet.map(f, 0, 1, _myMinReal, _myMaxReal ) );
      }
    }
  }
}
public class Transport {
  Group group;
  Textfield postureName;
  Button prevPostureButton;
  Button nextPostureButton;
  ButtonRec buttonRec;
  Numberbox animDuration;
  
  private int barHeight = 10;
  private int height = 20;
  private int width;
  private int spacing = 2;
  private int textfieldWidth = 100;
  private int buttonSize = 24;
  private int x = 200;
  private int y = margin + barHeight;
  private float prevAnimDuration = 0f;


  public Transport() {
    group = cp5.addGroup("transportgroup")
      .setBarHeight(barHeight)
      .setBackgroundHeight(height + 1)
      .setBackgroundColor(backgroundColor)
      .setCaptionLabel("transport")
      .setPosition(x, y)
      ;
    
    PVector pos = new PVector(0, 0);

    prevPostureButton = cp5.addButton("prevposture")
      .setLabel("<<")
      .setPosition(pos.x, pos.y)
      .setSize(buttonSize, height)
      .setGroup(group)
      ;
    prevPostureButton.addCallback(new CallbackListener() {
      public void controlEvent(CallbackEvent theEvent) {
        if (theEvent.getAction() == ControlP5.ACTION_CLICK) {
          if (postureIndex <= 0)
            return;
          if (animationCollectionDirty) {
            // Save fullAnimation to animationCollection
            savePosture();
          }
          postureIndex--;
          Posture prevPosture = postures.getPosture(postureIndex);
          avatar.loadPosture(prevPosture);
          postureName.setText(prevPosture.name);
          animDuration.setValue(prevPosture.duration);
          prevAnimDuration = prevPosture.duration;
          mustUpdateUI = true;
        }
      }
    });
    pos.add(buttonSize + spacing, 0);


    postureName = cp5.addTextfield("posturename")
      //.setLabelVisible(false) // Doesn't work
      .setLabel("")
      .setText("posture0")
      .setPosition(pos.x, pos.y)
      .setSize(textfieldWidth, height)
      .setFont(defaultFont)
      .setFocus(false)
      .setColor(color(255, 255, 255))
      .setAutoClear(false)
      .setGroup(group)
      ;
    pos.add(textfieldWidth + spacing, 0);


    nextPostureButton = cp5.addButton("nextposture")
      .setLabel(">>")
      .setPosition(pos.x, pos.y)
      .setSize(buttonSize, height)
      .setGroup(group)
      ;
    nextPostureButton.addCallback(new CallbackListener() {
      public void controlEvent(CallbackEvent theEvent) {
        if (theEvent.getAction() == ControlP5.ACTION_CLICK) {
          if (animationCollectionDirty) {
            // Save posture to animationCollection
            savePosture();
          }
          postureIndex++;
          if (postureIndex >= postures.size()) {
            postureIndex = postures.size();
            avatar.clearAnimation();
            postureName.setText("posture" + postureIndex);
            animDuration.setValue(0f);
            prevAnimDuration = 0f;
          } else {
            Posture nextPosture = postures.getPosture(postureIndex);
            avatar.loadPosture(nextPosture);
            postureName.setText(nextPosture.name);
            animDuration.setValue(nextPosture.duration);
            prevAnimDuration = nextPosture.duration;
          }
          mustUpdateUI = true;
        }
      }
    });
    pos.add(buttonSize + 2*spacing, 0);


    buttonRec = new ButtonRec(cp5, "buttonrec", pos);
    buttonRec.setGroup(group);
    pos.add(buttonSize + spacing, 0);

    animDuration = new NumberboxInput(cp5, "animduration")
      .setPosition(pos.x, pos.y)
      .setSize(40, height)
      .setGroup(group);
    animDuration.addCallback(new CallbackListener() {
      public void controlEvent(CallbackEvent theEvent) {
        if (theEvent.getAction() == ControlP5.ACTION_BROADCAST && animDuration.getValue() != prevAnimDuration) {
          animationCollectionDirty = true;
        }
      }
    });
    pos.add(animDuration.getWidth(), 0);


    width = (int) pos.x;
    group.setWidth(width);
    hide();
  }
  
  
  public boolean contains(int x, int y) {
    return (x >= this.x && x <= this.x+width && y >= this.y-barHeight && y <= this.y);
  }
  
  
  public void move(int dx, int dy) {
    group.open();
    x += dx;
    y += dy;
    x = max(1, min(sketchWidth() - group.getWidth() - 1, x));
    y = max(barHeight + 2, min(sketchHeight() - height - 1, y));
    group.setPosition(x, y);
  }
  
  
  public void setPosition(int x, int y) {
    this.x = x;
    this.y = y;
    group.setPosition(x, y);
  }


  public void show() {
    group.show();
  }

  public void hide() {
    group.hide();
  }


  private class ButtonRec extends Button {
    public ButtonRec(ControlP5 theControlP5, String theName, PVector position) {
      super(theControlP5, theName);
      setLabel("Rec");
      setSize(buttonSize, height);
      setPosition(position.x, position.y);
      setSwitch(true);
      setColorActive(color(255, 0, 0));
    }

    @Override
    public void mousePressed() {
      super.mousePressed();
      if (isOn()) {
        mainScreen.stopRecording();
      } else {
        mainScreen.startRecording();
      }
    }
  }
}
ControlP5 cp5;
FunctionAccordion accordion;
MyScrollableList partsList;
Transport transport;
Button pivotButton;
Timeline timeline;

PFont defaultFont;
int spacing = 4;
int margin = spacing;
int menuBarHeight = 18;
int groupBarHeight = 16;
int keepsOpenAnimNum = -1;
int axeWidth = 72;
boolean isNumberboxActive = false;
int backgroundColor = color(0, 100);



class MyScrollableList extends ScrollableList {
  int oldItemHover = -1;

  public MyScrollableList(ControlP5 theControlP5, String theName) { 
    super(theControlP5, theName);
    setType(ScrollableList.LIST);
    setFont(defaultFont);
    setBarHeight(0);
    setBarVisible(false);
    setWidth(120);
  }

  public void highlightPart() {
    if (itemHover != oldItemHover) {
      if (itemHover >= 0 && itemHover < avatar.getPartsList().length) {
        renderer.setSelected(avatar.getPartsList()[itemHover]);
      }
    }
    oldItemHover = itemHover;
  } 

  @Override protected void onEnter() {
    super.onEnter();
    highlightPart();
  }
  @Override protected void onLeave() {
    super.onLeave();
    renderer.setSelected(selected);
  }
  @Override protected void onMove() {
    super.onMove();
    highlightPart();
  }
}



public class FunctionAccordion extends Accordion {
  private int accordionWidth = 207;

  public FunctionAccordion(ControlP5 theControlP5, String theName) {
    super(theControlP5, theName);
    setWidth(accordionWidth);
    setMinItemHeight(0);
    setCollapseMode(ControlP5.SINGLE);
    spacing = 4;
  }

  // Stupid hack to fix a stupid bug
  // (groups used to collapse in wrong order after mouse hovered a scrollable list)
  @Override
  public void controlEvent( ControlEvent theEvent ) {
    super.controlEvent(theEvent);
    String[] m = match(theEvent.getName(), "animation(\\d+)");
    keepsOpenAnimNum = parseInt(m[1]);
    mustUpdateUI = true;
  }
}



public class NumberboxInput extends Numberbox {
  private String text = "";
  private boolean active;

  NumberboxInput(ControlP5 theControlP5, String theName) {
    super(theControlP5, theName);
    setLabel("");
    
    // control the active-status of the input handler when releasing the mouse button inside 
    // the numberbox. deactivate input handler when mouse leaves.
    onClick(new CallbackListener() {
      public void controlEvent(CallbackEvent theEvent) {
        setActive( true );
      }
    });
    
    onLeave(new CallbackListener() {
      public void controlEvent(CallbackEvent theEvent) {
        setActive( false );
        submit();
      }
    });
  }

  public void keyEvent(KeyEvent k) {
    // only process key event if input is active 
    if (k.getAction() == KeyEvent.PRESS && active) {
      if (k.getKey() == '\n') { // confirm input with enter
        submit();
        return;
      } else if (k.getKeyCode() == BACKSPACE) { 
        text = text.isEmpty() ? "" : text.substring(0, text.length()-1);
      } else if (k.getKey() < 255) {
        // check if the input is a valid (decimal) number
        final String regex = "-?(\\d+(.\\d{0,3})?)?";
        String s = text + k.getKey();
        if ( java.util.regex.Pattern.matches(regex, s ) ) {
          text += k.getKey();
        }
      }
      getValueLabel().setText(this.text);
    }
  }

  public void setActive(boolean b) {
    active = b;
    isNumberboxActive = b;
    if (active) {
      getValueLabel().setText("");
      text = "";
    }
  }

  public void submit() {
    if (!text.isEmpty()) {
      final String regex = "-?\\d+(.\\d{0,3})?";
      if (java.util.regex.Pattern.matches(regex, text)) {
        setValue( PApplet.parseFloat( text ) );
      } else {
        setValue(0f);
      }
      text = "";
    } else {
      getValueLabel().setText("" + getValue());
    }
  }
}



public void setupUI() {
  //printArray(PFont.list());
  defaultFont = createFont("DejaVu Sans Mono", 12);

  cp5 = new ControlP5(this);

  partsList = (MyScrollableList) new MyScrollableList(cp5, "partslist")
    .setLabel("parts list")
    .setPosition(margin, margin)
    .setHeight(height-2*margin)
    .setItemHeight(menuBarHeight)
    .hide();
  ;

  transport = new Transport();
  accordion = new FunctionAccordion(cp5, "accordion");

  pivotButton = cp5.addButton("pivotbutton")
    .setPosition(300, 10)
    .setSize(70, 20)
    .setSwitch(true)
    .activateBy(ControlP5.PRESS)
    .setLabel("Set pivot")
    .hide()
    ;
}



public void updateUI() {
  paramLocked = true;

  partsList.open().show();

  // Remove accordion and create new one
  if (accordion != null) {
    cp5.remove("accordion");
    accordion = null;
  }
  accordion = new FunctionAccordion(cp5, "accordion");
  accordion.setPosition(width-accordion.getWidth()-margin, 1);

  PVector pos = new PVector();
  Animation[] animationList = selected.getAnimationList();
  int animNum = 0;
  Group g;

  for (Animation anim : animationList) {
    pos.set(spacing, spacing);

    g = cp5.addGroup("animation"+animNum)
      .setLabel("animation "+animNum)
      //.setFont(defaultFont)
      .setBarHeight(groupBarHeight)
      .setBackgroundColor(color(0, 100))
      ;

    cp5.addScrollableList("function"+animNum)
      .setLabel("function")
      .setFont(defaultFont)
      .setPosition(pos.x, pos.y)
      .setBarHeight(menuBarHeight)
      .setItemHeight(menuBarHeight)
      .onEnter(toFront)
      .onLeave(close)
      .addItems(functionsName)
      .setValue(Arrays.asList(Animation.timeFunctions).indexOf(anim.getFunction().getClass()))
      .setGroup(g)
      .close()
      ;
    pos.add(cp5.getController("function"+animNum).getWidth() + spacing, 0);

    cp5.addScrollableList("axe"+animNum)
      .setLabel("axe")
      .setFont(defaultFont)
      .setPosition(pos.x, pos.y)
      .setWidth(axeWidth)
      .setBarHeight(menuBarHeight)
      .setItemHeight(menuBarHeight)
      .onEnter(toFront)
      .onLeave(close)
      .addItems(Animation.axeNames)
      .setValue(anim.getAxe() >= 0 ? anim.getAxe() : 0)
      .setGroup(g)
      .close()
      ;
    pos.add(cp5.getController("axe"+animNum).getWidth() + spacing, 0);

    // Delete animation button
    cp5.addButton("deletebutton"+animNum)
      .setLabel("x")
      .setColorBackground(0xffff0000)
      .setPosition(pos.x, pos.y)
      .setSize(menuBarHeight, menuBarHeight)
      .activateBy(ControlP5.PRESS)
      .setGroup(g)
      ;
    pos.set(spacing, 2*spacing + cp5.getController("axe"+animNum).getHeight());
    pos.add(0.f, spacing);


    // Draw specific parameters
    if (anim.getFunction() instanceof TFTimetable) {
      if (timeline == null) {
        timeline = new Timeline(animNum);
        timeline.setFunction((TFTimetable) anim.getFunction());
      }

      cp5.addButton("showtimeline"+animNum)
        .setLabel("Open Timeline")
        .setPosition(pos.x, pos.y)
        .setSize(60, 20)
        .activateBy(ControlP5.PRESS)
        .setGroup(g)
        ;
      pos.add(0.f, 20+spacing);
    } else {
      drawParams(g, animNum, pos);
    }
    pos.add(spacing, spacing);

    // Draw Animation general parameters
    cp5.addKnob("animamp"+animNum)
      .setLabel("")
      //.setLabelVisible(false)
      .setPosition(pos.x, pos.y)
      .setRange(0, 500)
      .setResolution(-500f)  // A negative resolution inverse the drag direction
      .setScrollSensitivity(0.0001f)
      .setValue(anim.getAmp())
      .setRadius(20)
      .setDragDirection(Knob.VERTICAL)
      .setGroup(g)
      ;
    cp5.addTextlabel("amp"+animNum+"label")
      .setPosition(pos.x + 35 + spacing, pos.y + 16)
      .setText("amp".toUpperCase())
      .setGroup(g)
      ;
    pos.set(accordion.getWidth()-82, pos.y);

    cp5.addToggle("animinv"+animNum)
      .setLabelVisible(false)
      .setPosition(pos.x, pos.y + 10)
      .setSize(40, 20)
      .setMode(ControlP5.SWITCH)
      .setValue(!anim.getInv())
      .setGroup(g)
      ;
    cp5.addTextlabel("inv"+animNum+"label")
      .setPosition(pos.x + 38 + spacing, pos.y + 15)
      .setText("invert".toUpperCase())
      .setGroup(g)
      ;
    pos.add(0, cp5.getController("animamp"+animNum).getHeight());

    pos.set(spacing, pos.y+spacing*2);
    drawBottomButtons(g, animNum, pos);

    g.setBackgroundHeight((int) pos.y);
    accordion.addItem(g);
    animNum++;
  }

  // Add an empty accordion panel for new animations
  pos.set(spacing, spacing);
  g = cp5.addGroup("animation"+animNum)
    .setLabel("animation "+animNum)
    //.setFont(defaultFont)
    .setBarHeight(groupBarHeight)
    .setBackgroundColor(color(0, 100))
    ;

  cp5.addScrollableList("function"+animNum)
    .setLabel("function")
    .setFont(defaultFont)
    .setPosition(pos.x, pos.y)
    .setBarHeight(menuBarHeight)
    .setItemHeight(menuBarHeight)
    .onEnter(toFront)
    .onLeave(close)
    .addItems(functionsName)
    .moveTo(g)
    .close()
    ;
  pos.add(cp5.getController("function"+animNum).getWidth() + spacing, 0);

  cp5.addScrollableList("axe"+animNum)
    .setLabel("axe")
    .setFont(defaultFont)
    .setPosition(pos.x, pos.y)
    .setWidth(axeWidth)
    .setBarHeight(menuBarHeight)
    .setItemHeight(menuBarHeight)
    .onEnter(toFront)
    .onLeave(close)
    .addItems(Animation.axeNames)
    .moveTo(g)
    .close()
    ;
  pos.set(spacing, 2*spacing + cp5.getController("axe"+animNum).getHeight());
  pos.add(0.f, spacing);

  drawBottomButtons(g, animNum, pos);

  g.setBackgroundHeight((int) pos.y);
  accordion.addItem(g);

  if (keepsOpenAnimNum >= 0 && keepsOpenAnimNum <= animationList.length) {
    accordion.open(keepsOpenAnimNum);
  } else {
    accordion.open(0);
  }

  paramLocked = false;
}



public void drawParams(Group g, int animNum, PVector pos) {
  Animation anim = selected.getAnimationList()[animNum];

  for (TFParam param : anim.getFunction().getParams()) {
    switch (param.type) {
    case TFParam.SLIDER:
      cp5.addSlider(param.name+animNum)
        .setLabel(param.name)
        .setPosition(pos.x, pos.y)
        .setWidth(accordion.getWidth()-40)
        .setHeight(16)
        .setRange(param.min, param.max)
        .setValue((float) param.getValue())
        .setGroup(g)
        ;
      break;

    case TFParam.CHECKBOX:
      cp5.addToggle(param.name+animNum)
        .setLabelVisible(false)
        .setPosition(pos.x, pos.y)
        .setSize(20, 20)
        .setValue((boolean) param.getValue())
        .setGroup(g)
        ;
      cp5.addTextlabel(param.name+animNum+"label")
        .setPosition(pos.x + 20 + spacing, pos.y + 4)
        .setText(param.name.toUpperCase())
        .setGroup(g)
        ;
      break;

    case TFParam.TOGGLE:
      cp5.addToggle(param.name+animNum)
        .setLabelVisible(false)
        .setPosition(pos.x, pos.y)
        .setSize(40, 20)
        .setMode(ControlP5.SWITCH)
        .setValue((int) param.getValue() == 1 ? true : false)
        .setGroup(g)
        ;
      cp5.addTextlabel(param.name+animNum+"label")
        .setPosition(pos.x + 40 + spacing, pos.y + 4)
        .setText(param.name.toUpperCase())
        .setGroup(g)
        ;
      break;

    case TFParam.NUMBERBOX:
      new NumberboxInput(cp5, param.name+animNum)
        //.setLabelVisible(false) // doesn't work
        .setPosition(pos.x, pos.y)
        .setSize(60, 20)
        .setRange(param.min, param.max)
        .setMultiplier(0.1f) // set the sensitifity of the numberbox
        .setDirection(Controller.HORIZONTAL) // change the control direction to left/right
        .setValue((float) param.getValue())
        .setGroup(g)
        ;
      cp5.addTextlabel(param.name+animNum+"label")
        .setPosition(pos.x + 60 + spacing, pos.y + 4)
        .setText(param.name.toUpperCase() + (param.unit.equals("") ? "" : "  ("+param.unit+")"))
        .setGroup(g)
        ;
      break;

    case TFParam.EASING:
      int easingNum = 0;
      for (int i=0; i<Animation.interpolationNamesSimp.length; i++) {
        if (Animation.interpolationNamesSimp[i].equals((String) param.getValue())) {
          easingNum = i;
          break;
        }
      }
      cp5.addScrollableList(param.name+animNum)
        .setLabel("easing function")
        .setPosition(pos.x, pos.y)
        .setBarHeight(menuBarHeight)
        .setItemHeight(menuBarHeight)
        .onEnter(toFront)
        .onLeave(close)
        .addItems(Animation.interpolationNamesSimp)
        .setValue(easingNum)
        .setGroup(g)
        .close()
        ;
      break;
    }
    pos.add(0, cp5.getController(param.name+animNum).getHeight()+spacing);
  }
}



public void drawBottomButtons(Group g, int animNum, PVector pos) {
  boolean bottomButtons = false;

  if (animNum < selected.getAnimationList().length) {
    // Copy animation
    cp5.addButton("copybutton"+animNum)
      .setLabel("copy")
      .setPosition(pos.x, pos.y)
      .setSize(40, 20)
      .activateBy(ControlP5.PRESS)
      .setGroup(g)
      ;
    pos.add(cp5.getController("copybutton"+animNum).getWidth()+spacing, 0);

    // Swap position buttons
    cp5.addButton("swapup"+animNum)
      .setLabel("up")
      .setPosition(accordion.getWidth()-42-margin, pos.y)
      .setSize(20, 20)
      .activateBy(ControlP5.PRESS)
      .setGroup(g)
      ;
    if (animNum < 1)
      cp5.getController("swapup"+animNum).hide();

    cp5.addButton("swapdown"+animNum)
      .setLabel("dwn")
      .setPosition(accordion.getWidth()-20-margin, pos.y)
      .setSize(20, 20)
      .activateBy(ControlP5.PRESS)
      .setGroup(g)
      ;
    if (animNum == selected.getAnimationList().length-1)
      cp5.getController("swapdown"+animNum).hide();

    bottomButtons = true;
  }

  if (animationClipboard != null) {
    // Paste animation
    cp5.addButton("pastebutton"+animNum)
      .setLabel("paste")
      .setPosition(pos.x, pos.y)
      .setSize(42, 20)
      .activateBy(ControlP5.PRESS)
      .setGroup(g)
      ;
    bottomButtons = true;
  }

  if (bottomButtons == true)
    pos.add(0, 20+2*spacing);
}



public void showUI() {
  showUI = true;
  accordion.show();
  partsList.open().show();
  transport.show();
  renderer.setSelected(selected);
}

public void hideUI() {
  showUI = false;
  accordion.hide();
  partsList.hide();
  pivotButton.hide();
  transport.hide();
  renderer.setSelected(null);
}



CallbackListener toFront = new CallbackListener() {
  public void controlEvent(CallbackEvent theEvent) {
    theEvent.getController().getParent().bringToFront();
    theEvent.getController().bringToFront();
    ((ScrollableList)theEvent.getController()).open();
  }
};

CallbackListener close = new CallbackListener() {
  public void controlEvent(CallbackEvent theEvent) {
    ((ScrollableList)theEvent.getController()).close();
  }
};
public class WelcomeScreen extends Screen {
  ComplexShape mill;
  float innerRadius;

  public WelcomeScreen() {
    int numWings = floor(random(8, 32));
    innerRadius = numWings * 4;
    float duration = 8f;
    int r1 = floor(random(1, 12));

    // Single wing shape
    float[] verts = new float[] {0f, 10f, 100f, 18f, 106f, 6f, 110f, 0f, 106f, -6f, 100f, -18f, 0f, -10f};
    ComplexShape wing = new ComplexShape();
    DrawablePolygon shape = new DrawablePolygon(verts);
    colorMode(HSB, 1f);
    int c = color(random(1), 0.3f, 1f);
    shape.setColor(red(c), green(c), blue(c), 1f);
    colorMode(RGB, 255);
    wing.addShape(shape);
    TimeFunction stretch = new TFSin(duration*random(0.4f, 2f), 0.3f, map(numWings, 8, 32, 1, 1.5f), 0f);
    wing.addAnimation(new Animation(stretch, Animation.AXE_SX));
    TimeFunction translate = new TFConstant(innerRadius);
    wing.addAnimation(new Animation(translate, Animation.AXE_X));

    mill = new ComplexShape();
    for (int i=0; i<numWings; i++) {
      ComplexShape newWing = wing.copy();
      newWing.setColorMod(random(0.9f, 1.1f), random(0.9f, 1.1f), random(0.9f, 1.1f), 1f);
      newWing.getAnimation(0).setParam("phase", r1*i*360/numWings);
      TimeFunction rotate = new TFConstant((float) i/numWings);
      newWing.addAnimation(new Animation(rotate, Animation.AXE_ROT));
      mill.addShape(newWing);
    }

    TimeFunction spin = new TFSpin(0f, duration * random(3f, 4f), 1f);
    mill.addAnimation(new Animation(spin, Animation.AXE_ROT));
  }

  @Override
  public void draw() {
    if (avatar != null) {
      showUI();
      currentScreen = mainScreen;
      return;
    }

    background(255);
    
    pushMatrix();
    translate(innerRadius*1.3f, innerRadius*1.3f);
    //translate(width/2, height);
    //scale(1.5);
    mill.update(1f/frameRate);
    mill.draw(renderer);
    popMatrix();
    
    fill(127);
    textSize(32);
    text("Press       +      to load a file", width/3, height/2);
    drawKey(width/3 + 96, height/2 - 32, "Ctrl", 40);
    drawKey(width/3 + 188, height/2 - 32, "O", 40);
    
    fill(63);
    textSize(20);
    text("to show help", (width/2) - 50, 60 + height/2);
    drawKey((width/2) - 90, 36 + height/2, "H", 32);
    
    text("Ver. "+version, width-110, height-20);
  }

  public @Override
  void mouseClicked(MouseEvent event) {
    selectInput("Select a file", "inputFileSelected");
    loadScreen = new LoadScreen();
  }

  public @Override
  void keyPressed(KeyEvent event) {
    switch (key) {
    case 'h':  // Help screens
      currentScreen = helpScreen1;
      break;
    case 15:  // CTRL+o, load a new file
      selectInput("Select a file", "inputFileSelected");
      loadScreen = new LoadScreen();
      break;
    }
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SgAnimator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
