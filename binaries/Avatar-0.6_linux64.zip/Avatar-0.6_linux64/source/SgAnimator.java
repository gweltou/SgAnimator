import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import com.badlogic.gdx.graphics.*; 
import com.badlogic.gdx.math.*; 
import com.badlogic.gdx.utils.*; 
import gwel.spacegame.anim.*; 
import gwel.spacegame.graphics.*; 
import gwel.spacegame.entities.*; 
import controlP5.*; 
import java.util.Deque; 
import java.util.ArrayDeque; 
import java.util.*; 
import java.lang.reflect.Field; 
import java.lang.reflect.Constructor; 
import java.lang.reflect.InvocationTargetException; 
import java.io.FileInputStream; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class SgAnimator extends PApplet {

// TODO:

// Record images key ('r')
// Draw Coordinate's lines on editor
// Ability to scale Avatar to normalise objects sizes according to a standard ref (1m)
// Elastic function
// Arrondir à 2 décimales les floats à sauvegarder dans les json
// Option to duplicate previous AnimationCollection when new animCollection
// UV coords in polygon class
// Add a chart for every Animation to show function progression over time
// Lib : avatar.playSequencialy()

/*
  BUGS:
 * Animations don't scale when hardTransforming geometry
 * Seule la première animation est sauvegardée
 * Can't select axe before function
 */
















String version = "0.6";


MainScreen mainScreen;
LoadScreen loadScreen;
Screen welcomeScreen;
Screen helpScreen1;
Screen helpScreenEasing;
Screen currentScreen;

Renderer renderer;
Avatar avatar;
String baseFilename;

ComplexShape selected = null;
int selectedIndex = 0;
String[] partsName;
String[] functionsName;
AnimationCollection animationCollection;
int fullAnimationIndex = 0;
boolean fullAnimationDirty = false;
Animation animationClipboard;
float lastTime;

boolean showUI = false;
boolean paramLocked = false;
boolean setPivot = false;
boolean playAnim = true;
boolean mustUpdateUI = false;
File mustLoad = null; // Change current screen to loading screen


public void settings() {
  size(1200, 700);
  //fullScreen();
}


public void setup() {
  surface.setResizable(true);
  surface.setTitle("Avatar5");

  mainScreen = new MainScreen();
  welcomeScreen = new WelcomeScreen();
  helpScreen1 = new HelpScreen1();
  helpScreenEasing = new HelpScreenEasing();
  currentScreen = welcomeScreen;
  
  renderer = new Renderer(this);

  int numFn = Animation.timeFunctions.length;
  functionsName = new String[numFn];
  for (int i=0; i<numFn; i++) {
    int idx = Animation.timeFunctions[i].getName().lastIndexOf('.');
    functionsName[i] = Animation.timeFunctions[i].getName().substring(idx+3);
  }

  setupUI();

  lastTime = (float) millis() / 1000.0f;

  // Load a default file
  /*
  File f = new File("/home/gweltaz/Bureau/ruz.json");
   avatar = loadAvatarFile(f);
   partsName = new String[avatar.getPartsList().length];
   for (int i=0; i<partsName.length; i++) {
   partsName[i] = avatar.getPartsList()[i].getId();
   }
   partsList.setItems(partsName);
   animName.setText(animationCollection.getFullAnimationName(fullAnimationIndex));
   baseFilename = "/home/gweltaz/Bureau/ruz";
   showUI();
   */
}


public ComplexShape buildBlob() {
  // A try at a generative rigging
  int n = 10;

  ComplexShape root = new ComplexShape();
  ComplexShape parent = root;
  float x = 0;
  for (int i=0; i<n; i++) {
    ComplexShape segment = new ComplexShape();
    segment.addShape(new DrawableCircle(x, 0, 20));
    float[] verts = {x, 10, x+50, 6, x+50, -6, x, -10};
    segment.addShape(new DrawablePolygon(verts, null));
    segment.setLocalOrigin(x, 0);
    Animation[] anims = new Animation[1];
    anims[0] = new Animation(new TFSin(0.2f, 0.3f, 0f, x*0.012f), Animation.AXE_ROT);
    segment.setAnimationList(anims);
    parent.addShape(segment);
    parent = segment;
    x += 50;
  }
  return root;
}



public void select(ComplexShape part) {
  showUI = true;
  selected = part;
  updateUI();
  renderer.setSelected(part);
}



public void saveFullAnimation(String animName, int animIndex) {
  HashMap<String, Animation[]> fullAnimation = new HashMap();

  if (animName == null || animName.trim().isEmpty())
    animName = "anim"+animIndex;

  for (ComplexShape part : avatar.getPartsList()) {
    if (part.getAnimationList().length > 0)
      fullAnimation.put(part.getId(), part.getAnimationList());
  }

  if (animIndex >= animationCollection.size()) {
    animationCollection.addFullAnimation(animName, fullAnimation);
  } else {
    animationCollection.updateFullAnimation(animIndex, animName, fullAnimation);
  }

  fullAnimationDirty = false;
}


public void draw() {
  if (mustLoad != null) {
    loadScreen.setupUI(mustLoad);
    currentScreen = loadScreen;
    mustLoad = null;
  }

  currentScreen.draw();
}


public void keyPressed(KeyEvent event) { currentScreen.keyPressed(event); }
public void keyReleased(KeyEvent event) { currentScreen.keyReleased(event); }
public void mouseClicked(MouseEvent event) {currentScreen.mouseClicked(event); }
public void mouseWheel(MouseEvent event) { currentScreen.mouseWheel(event); }
public void mouseDragged(MouseEvent event) { currentScreen.mouseDragged(event); }


public abstract class Screen {
  public void draw() { }
  
  public void keyPressed(KeyEvent event) { }
  public void keyReleased(KeyEvent event) { }
  public void mouseClicked(MouseEvent event) { }
  public void mouseWheel(MouseEvent event) { }
  public void mouseDragged(MouseEvent event) { }
}



public void controlEvent(ControlEvent event) throws InstantiationException, IllegalAccessException, NoSuchMethodException, InvocationTargetException  {
  if (event.isController() && !paramLocked) {
    if (timeline != null)
      timeline.hide();
    
    String name = event.getName();
    float value = event.getValue();
    //println("event", name, value);
    
    if (name.equals("partslist")) {
      select(avatar.getPartsList()[PApplet.parseInt(value)]);
      selectedIndex = PApplet.parseInt(partsList.getValue());
    }
    
    else if (name.equals("animname")) {
      // Change fullAnim name
      println(animName.getText());
      fullAnimationDirty = true;
    }
    else if (name.equals("prevanim")) {
      if (fullAnimationIndex <= 0)
        return;
      
      if (fullAnimationDirty) {
        // Save fullAnimation to animationCollection
        saveFullAnimation(animName.getText(), fullAnimationIndex);
      }
      fullAnimationIndex--;
      avatar.setFullAnimation(animationCollection.getFullAnimation(fullAnimationIndex));
      animName.setText(animationCollection.getFullAnimationName(fullAnimationIndex));
      mustUpdateUI = true;
    }
    else if (name.equals("nextanim")) {
      if (fullAnimationDirty) {
        // Save fullAnimation to animationCollection
        saveFullAnimation(animName.getText(), fullAnimationIndex);
      }
      
      fullAnimationIndex++;
      if (fullAnimationIndex >= animationCollection.size()) {
        fullAnimationIndex = animationCollection.size();
        avatar.clearAnimation();
        animName.setText("anim"+fullAnimationIndex);
      } else {
        avatar.setFullAnimation(animationCollection.getFullAnimation(fullAnimationIndex));
        animName.setText(animationCollection.getFullAnimationName(fullAnimationIndex));
      }
      mustUpdateUI = true;
    }
    
    else if (name.startsWith("function")) {
      String[] m = match(name, "function(\\d+)");
      int animNum = parseInt(m[1]);
      Class<TimeFunction> tfclass = Animation.timeFunctions[(int) event.getValue()];
      Constructor<TimeFunction> ctor = tfclass.getConstructor();
      TimeFunction tf = ctor.newInstance();
      int numberOfAnimations = selected.getAnimationList().length;
      if (animNum < numberOfAnimations) {
        // Transfer compatible parameters to new TimeFunction
        //for (TFParam param : selected.getAnimation(animNum).getFunction().getParams()) {
        //  Object payload = param.getValue();
        //  println(payload.getClass());
        //  //tf.setParam(param.name, param.getValue()); // BROKEN
        //}
        selected.getAnimation(animNum).setFunction(tf);
      } else {
        selected.addAnimation(new Animation(tf));
      }
      selected.resetAnimation();
      if (tf instanceof TFTimetable) {
        timeline = new Timeline(animNum);
        timeline.setFunction((TFTimetable) tf);
        timeline.show();
      }
      mustUpdateUI = true;
      playAnim = true;
      fullAnimationDirty = true;
    }
    
    else if (name.startsWith("axe")) {
      String[] m = match(name, "axe(\\d+)");
      int animNum = parseInt(m[1]);
      selected.getAnimation(animNum).setAxe((int) value);
      mustUpdateUI = true;
      playAnim = true;
      fullAnimationDirty = true;
      if (timeline != null && animNum == timeline.getAnimNum())
        timeline.show();
    }
    
    else if (name.startsWith("animamp")) {
      String[] m = match(name, "animamp(\\d+)");
      int animNum = parseInt(m[1]);
      selected.getAnimation(animNum).setAmp(value);
      fullAnimationDirty = true;
    }
    
    else if (name.startsWith("animinv")) {
      String[] m = match(name, "animinv(\\d+)");
      int animNum = parseInt(m[1]);
      selected.getAnimation(animNum).setInv(value == 0 ? true : false);
      fullAnimationDirty = true;
    }
    
    else if (name.equals("pivotbutton")) {
      setPivot = ((Button) cp5.getController("pivotbutton")).isOn();
      avatar.resetAnimation();
      playAnim = false;
    }
    
    else if (name.startsWith("copybutton")) {
      String[] m = match(name, "copybutton(\\d+)");
      int animNum = parseInt(m[1]);
      animationClipboard = selected.getAnimation(animNum).copy();
      mustUpdateUI = true;
    }
    
    else if (name.startsWith("pastebutton")) {
      String[] m = match(name, "pastebutton(\\d+)");
      int animNum = parseInt(m[1]);
      if (animationClipboard != null) {
        selected.resetAnimation();
        if (animNum < selected.getAnimationList().length) {
          selected.setAnimation(animNum, animationClipboard);
        } else {
          selected.addAnimation(animationClipboard);
        }
        mustUpdateUI = true;
        fullAnimationDirty = true;
      }
    }
    
    else if (name.startsWith("deletebutton")) {
      String[] m = match(name, "deletebutton(\\d+)");
      int animNum = parseInt(m[1]);
      selected.resetAnimation(); // So transform matrix is set to identity
      selected.removeAnimation(animNum);
      mustUpdateUI = true;
      fullAnimationDirty = true;
    }
    
    else if (name.startsWith("swapup")) {
      String[] m = match(name, "swapup(\\d+)");
      int animNum = parseInt(m[1]);
      Animation moveup = selected.getAnimation(animNum);
      selected.setAnimation(animNum, selected.getAnimation(animNum-1));
      selected.setAnimation(animNum-1, moveup);
      //updateUI();
      keepsOpenAnimNum = animNum-1;
      mustUpdateUI = true;
      fullAnimationDirty = true;
    }
    
    else if (name.startsWith("swapdown")) {
      String[] m = match(name, "swapdown(\\d+)");
      int animNum = parseInt(m[1]);
      Animation moveup = selected.getAnimation(animNum+1);
      selected.setAnimation(animNum+1, selected.getAnimation(animNum));
      selected.setAnimation(animNum, moveup);
      //updateUI();
      keepsOpenAnimNum = animNum+1;
      mustUpdateUI = true;
      fullAnimationDirty = true;
    }
    
    else if (name.startsWith("showtimeline")) {
      String[] m = match(name, "([a-z]+)(\\d+)");
      if (m != null) {
        int animNum = parseInt(m[2]);
        timeline.setFunction((TFTimetable) selected.getAnimation(animNum).getFunction());
      }
      timeline.show();
    }
    
    else if (name.startsWith("tl")) {
      // Timeline specific parameters
      String[] m = match(name, "([a-z]+)(\\d+)");
      if (m != null) {
        if (m[1].equals("tlnumsteps")) {
          timeline.updateTable();
        }
        else if (m[1].equals("tlslider")) {
          timeline.setTableValue(Integer.parseInt(m[2]), value);
        }
        else if (m[1].equals("tllshift")) {
          timeline.lshift();
        }
        else if (m[1].equals("tlrshift")) {
          timeline.rshift();
        }
      }
      timeline.show();
      fullAnimationDirty = true;
    }
    
    else {
      String[] m = match(name, "([a-z]+)(\\d+)");
      if (m != null) {
        String paramName = m[1];
        int animNum = parseInt(m[2]);
        TimeFunction fn = selected.getAnimation(animNum).getFunction();
        if (paramName.equals("easing")) {
          // Send value as a string (name of the easing function)
          int idx = floor(value);
          fn.setParam(paramName, Animation.interpolationNamesSimp[idx]);
        } else {
          fn.setParam(paramName, value);
        }
        playAnim = true;
        fullAnimationDirty = true;
        if (timeline != null && timeline.getFunction() == fn)
          timeline.show();
      }
    }
  }
}




public void fileSelected(File selection) throws IOException { 
  if (selection == null) {
    println("Window was closed or the user hit cancel.");
  } else {
    println("User selected " + selection.getAbsolutePath());
    String filename = selection.getAbsolutePath();
    if (filename.endsWith("svg")) {
      ComplexShape shape = ComplexShape.fromPShape(loadShape(filename));
      if (shape == null)
        return;
      
      selectedIndex = 0;
      selected = null;
      // Go down the complexShape tree if the root is empty
      while (shape.getShapes().size() == 1 && shape.getChildren().size() == 1)
        shape = (ComplexShape) shape.getShapes().get(0);
      
      animationCollection = new AnimationCollection();
      avatar = new Avatar();
      avatar.setShape(shape);
      partsName = new String[avatar.getPartsList().length];
      for (int i=0; i<partsName.length; i++) {
        partsName[i] = avatar.getPartsList()[i].getId();
      }
      partsList.setItems(partsName);
      baseFilename = filename.substring(0, filename.length()-4);
      
      
      currentScreen = mainScreen;
      animName.setText("anim0");
      mainScreen.resetView();
      showUI();
      accordion.hide();
      
    /*} else if (filename.endsWith("tdat")) {
      rootShape = loadGeometry(selection);
      File animFile = new File(filename.replace(".tdat", ".json"));
      if (animFile.exists()) {
        JSONObject rootElement = loadJSONObject(selection);
        loadAnimation(rootElement.getJSONArray("animation"));
      }*/
    } else if (filename.endsWith("json")) {
      mustLoad = selection;
    } else {
      println("Bad filename");
    }
  }
}
public class HelpScreen1 extends Screen {
  
  @Override
  public void draw() {
    background(255);
    fill(63);
    textSize(20);
    text("CTRL+o\n"+
      "CTRL+s\n"+
      "Up/Down\n"+
      "p\n"+
      "r\n"+
      "d\n"+
      "h\n"+
      "w\n"+
      "right click\n"+
      "MAJ + right drag\n", width/4, height/4);
    text("Open file (svg or json)\n"+
      "Save json file\n"+
      "Select next/previous shape group\n"+
      "Play/Pause animation\n"+
      "Reset animation\n"+
      "Show/Hide UI\n"+
      "Help screen\n"+
      "Wireframe\n"+
      "Place pivot\n"+
      "Translate geometry\n", width/2, height/4);
    text("Ver. "+version, width-110, height-20);
  }
  
  public void keyPressed(KeyEvent event) {
    if (key == 'h') {
      currentScreen = helpScreenEasing;
    }
  }
  
  public @Override
  void mouseClicked(MouseEvent event) {
    currentScreen = helpScreenEasing;
  }
}
public class HelpScreenEasing extends Screen {
  private int frameWidth = 120;
  private int frameHeight = 90;
  private int spacing = 8;
  private int margin = width/8;
  private PGraphics[] frames;


  HelpScreenEasing() {
    frames = new PGraphics[Animation.interpolationNamesSimp.length];
    int i = 0;
    for (String interpolationName : Animation.interpolationNamesSimp) {
      Interpolation fn = Animation.getInterpolation(interpolationName);
      frames[i++] = createInterpolationFrame(frameWidth, frameHeight, fn, interpolationName);
    }
  }


  public PGraphics createInterpolationFrame(int w, int h, Interpolation fn, String name) {
    PGraphics pg = createGraphics(w, h);
    pg.beginDraw();
    pg.background(0xffFFC500);
    float prev = h * fn.apply(0f);
    float val;
    float penX;
    float stepX = 2f;
    pg.stroke(0);
    for (penX=stepX; penX<w; penX+=stepX) {
      val = h * fn.apply(penX/w);
      pg.line(penX-stepX, h-prev, penX, h-val);
      prev = val;
    }
    val = h * fn.apply(1f);
    pg.line(penX-stepX, h-prev, w, h-val);
    pg.fill(0, 127);
    pg.text(name, w-textWidth(name)-4, h-4);
    pg.endDraw();
    return pg;
  }


  @Override
  public void draw() {
    background(255);
    fill(127);
    textSize(32);
    int offset = floor(textWidth("Easing functions"));
    text("Easing functions", (width/2)-offset/2, -20+height/6);

    int posX = margin;
    int posY = height/5;
    for (PGraphics frame : frames) {
      image(frame, posX, posY);
      posX += frameWidth + spacing;
      if (posX + frameWidth + spacing > width-margin) {
        posX = margin;
        posY += frameHeight + spacing;
      }
    }
  }


  public @Override
  void keyPressed(KeyEvent event) {
    if (avatar != null)
      showUI();
    currentScreen = mainScreen;
  }
  
  public @Override
  void mouseClicked(MouseEvent event) {
    if (avatar != null)
      showUI();
    currentScreen = mainScreen;
  }
}



public class LoadScreen extends Screen {
  private PImage backgroundImage;
  Group loadGroup;
  Toggle geomToggle, animToggle;
  int groupWidth = 180;
  int groupHeight = 180;
  String filename;
  File selection;
  boolean mustDestroy = false;
  
  public LoadScreen() {
    doBackground();
  }

  public void setupUI(File selection) {
    this.selection = selection;
    filename = selection.getAbsolutePath();

    hideUI();

    paramLocked = true;
    loadGroup = new Group(cp5, "loadfilegroup")
      .setWidth(groupWidth)
      .setBackgroundHeight(groupHeight)
      .setPosition((width/2)-(groupWidth/2), (height/2)-(groupHeight/2))
      .setBackgroundColor(color(0, 100))
      .hideBar()
      ;
    
    cp5.addTextlabel("filenamelabel")
      .setPosition(4, 10)
      .setFont(defaultFont)
      .setText(selection.getName())
      .setGroup(loadGroup)
      ;

    geomToggle = cp5.addToggle("loadgeometrytoggle")
      .setLabelVisible(false)
      .setPosition(groupWidth-56, 60)
      .setSize(20, 20)
      .setValue(1.0f)
      .setGroup(loadGroup)
      ;
    cp5.addTextlabel("loadgeometrylabel")
      .setPosition(32, 60 + 3)
      .setFont(defaultFont)
      .setText("Geometry")
      .setGroup(loadGroup)
      ;

    animToggle = cp5.addToggle("loadanimationtoggle")
      .setLabelVisible(false)
      .setPosition(groupWidth-56, 90)
      .setSize(20, 20)
      .setValue(1.0f)
      .setGroup(loadGroup)
      ;
    cp5.addTextlabel("loadanimationlabel")
      .setPosition(32, 90 + 3)
      .setFont(defaultFont)
      .setText("Animations")
      .setGroup(loadGroup)
      ;

    int okWidth = 50;
    cp5.addButton("loadokbutton")
      .removeCallback()
      .setWidth(okWidth)
      .setPosition((groupWidth/2)-(okWidth/2), groupHeight-34)
      .setLabel("Ok")
      .setGroup(loadGroup)
      .plugTo(this, "okFunction")
      ;
    paramLocked = false;
  }


  public void doBackground() {
    backgroundImage = createImage(width, height, RGB);
    loadPixels();
    arrayCopy(pixels, backgroundImage.pixels);
    backgroundImage.updatePixels();
    backgroundImage.filter(GRAY);
    backgroundImage.filter(BLUR, 3);
  }


  public void okFunction() {
    if (paramLocked == true)
      return;

    loadAvatarFile(selection);

    selectedIndex = 0;
    selected = null;
    partsName = new String[avatar.getPartsList().length];
    for (int i=0; i<partsName.length; i++) {
      partsName[i] = avatar.getPartsList()[i].getId();
    }
    partsList.setItems(partsName);
    baseFilename = filename.substring(0, filename.length()-5);
    showUI();
    accordion.hide();

    mustDestroy = true;
  }


  private void loadAvatarFile(File file) {
    JsonValue json = null;
    try {
      InputStream in = new FileInputStream(file);
      json = new JsonReader().parse(in);
    }
    catch (IOException e) {
      e.printStackTrace();
    }
    if (json == null)
      return;

    // Load shape first
    if (json.has("geometry") && geomToggle.getValue() == 1.0f) {
      JsonValue jsonGeometry = json.get("geometry");
      avatar = new Avatar();
      avatar.setShape(ComplexShape.fromJson(jsonGeometry));
      mainScreen.resetView();
    }

    // AnimationCollection is kept separated for simplicity
    // rather than storing and retrieving it from the Avatar class
    fullAnimationIndex = 0;
    if (json.has("animation") && animToggle.getValue() == 1.0f) {
      animationCollection = AnimationCollection.fromJson(json.get("animation"));
      //avatar.setAnimationCollection(animationCollection));
      if (animationCollection.size() > 0) {
        avatar.setFullAnimation(animationCollection.getFullAnimation(fullAnimationIndex));
        animName.setText(animationCollection.getFullAnimationName(fullAnimationIndex));
      }
    } else {
      animationCollection = new AnimationCollection();
    }
  }


  @Override
  public void draw() {
    if (backgroundImage != null) {
      image(backgroundImage, 0, 0);
    } else  {
      background(255);
    }

    if (mustDestroy) {
      loadGroup.remove();
      currentScreen = mainScreen;
    }
  }
}
public class MainScreen extends Screen {
  PImage selectpart;
  Affine2 transform;
  Affine2 hardTransform;
  TimeFunction selectpartAnim;
  
  
  public MainScreen() {
    selectpart = loadImage("selectpart.png");
    
    transform = new Affine2().setToTranslation(width/2, height/2);
    hardTransform = new Affine2 ();
    
    selectpartAnim = new TFEaseFromTo(60, 0, 0.66f, 0.66f, "bounceOut", false, true);
  }
  
  public void resetView() {
    transform.setToTranslation(width/2, height/2);
  }


  public void draw() {
    if (avatar == null) {
      hideUI();
      currentScreen = welcomeScreen;
      return;
    }
    
    float time = (float) millis() / 1000.0f;
    background(255);

    //if (avatar != null) {
      renderer.pushMatrix(transform);
      if (playAnim)
        avatar.updateAnimation(time-lastTime);
      avatar.draw(renderer);
      avatar.drawSelectedOnly(renderer);

      if (showUI) {
        renderer.drawPivot();
        renderer.drawMarker(0, 0);
        renderer.drawAxes();
        if (selected != null) {
          if (!hardTransform.isIdt()) {
            renderer.pushMatrix(hardTransform);
            selected.setColorMod(1f, 1f, 1f, 0.4f);
            selected.draw(renderer);
            selected.setColorMod(1f, 1f, 1f, 1f);
            renderer.popMatrix();
          }
        } else {
          selectpartAnim.update(1/frameRate);
          image(selectpart, partsList.getPosition()[0] + partsList.getWidth() + 4 + selectpartAnim.getValue(), partsList.getPosition()[1] + selectpartAnim.getValue()/3);
        }
      }
      renderer.popMatrix();
      if (playAnim == false && (frameCount>>5)%2 == 0) {
        fill(255, 0, 0, 127);
        textSize(32);
        text("PAUSED", -60+width/2, height-80);
      }
      if (timeline != null) {
        timeline.highlightSliders();
      }

      if (setPivot) {
        fill(255, 0, 0);
        noStroke();
        ellipse(mouseX, mouseY, 8, 8);
      }

      if (mustUpdateUI == true && selected != null) {
        updateUI();
        mustUpdateUI = false;
      }
    //}

    lastTime = time;
  }


  public void keyPressed(KeyEvent event) {
    if (avatar != null && key == CODED) {
      if (keyCode == UP) {  // Select next part
        selectedIndex = (selectedIndex-1);
        if (selectedIndex < 0)
          selectedIndex += avatar.getPartsList().length;
        partsList.setValue(selectedIndex);
      } else if (keyCode == DOWN) {  // Select previous part
        selectedIndex = (selectedIndex+1) % avatar.getPartsList().length;
        partsList.setValue(selectedIndex);
      } else if (keyCode == SHIFT && selected != null) {
        playAnim = false;
        avatar.resetAnimation();
      }
    } else if (!animName.isFocus()) {
      switch (key) {
      case 'p':  // Play/Pause animation
        if (avatar != null)
          playAnim = !playAnim;
        break;
      case 'r':  // Reset animation
        if (avatar != null)
          avatar.resetAnimation();
        if (selected != null) mustUpdateUI = true;
        break;
      case 'd':  // Show/Hide UI
        if (avatar != null) {
          if (showUI) {
            hideUI();
            if (timeline != null)
              timeline.hide();
          } else {
            showUI();
          }
        }
        break;
      case 'h':  // Help screens
        hideUI();
        currentScreen = helpScreen1;
        break;
      case 'w':  // Wireframe
        renderer.toggleWireframe();
        break;
      case 15:  // CTRL+o, load a new file
        selectInput("Select a file", "fileSelected");
        loadScreen = new LoadScreen();
        break;
      case 19: // CTRL+s, save
        if (avatar != null) {
          if (fullAnimationDirty)
            saveFullAnimation(animName.getText(), fullAnimationIndex);
          avatar.saveFile(baseFilename.concat(".json"), animationCollection);
        }
        break;
      }
    }
  }


  public void keyReleased(KeyEvent event) {
    if (key == CODED && keyCode == SHIFT && selected != null) {
      selected.hardTransform(hardTransform);
      hardTransform.idt();
      playAnim = true;
    }
  }


  public void mouseWheel(MouseEvent event) {
    if (!partsList.isInside()) {
      float z = pow(1.1f, -event.getCount());
      Affine2 unproject = new Affine2(transform).inv();
      Vector2 point = new Vector2(mouseX, mouseY);
      unproject.applyTo(point);
      transform.translate(point.x, point.y).scale(z, z).translate(-point.x, -point.y);
    }
  }


  public void mouseClicked(MouseEvent event) {
    if (event.getButton() == LEFT) {
      if (setPivot && !cp5.getController("pivotbutton").isInside()) {
        Vector2 point = new Vector2(mouseX, mouseY);
        Affine2 t = new Affine2(transform).inv();
        t.applyTo(point);
        selected.setLocalOrigin(point.x, point.y);
        ((Button) cp5.getController("pivotbutton")).setOff();
        playAnim = true;
      }
      pivotButton.hide();
    } else {
      // RIGHT CLICK opens context menu (pivot button)
      if (selected != null) {
        pivotButton.setPosition(mouseX, mouseY);
        pivotButton.show();
      }
    }
  }


  public void mouseDragged(MouseEvent event) {
    pivotButton.hide();
    if (event.getButton() == RIGHT) {
      int dx = mouseX-pmouseX;
      int dy = mouseY-pmouseY;
      if (keyPressed && keyCode == SHIFT && selected != null) {
        // scale translation by the zoom factor
        hardTransform.translate(dx/transform.m00, dy/transform.m11);
      } else {
        // scale translation by the zoom factor
        transform.translate(dx/transform.m00, dy/transform.m11);
      }
    }
  }
}
public final PFont BitFontStandard58 = new BitFont( CP.decodeBase64( BitFont.standard58base64 ) );


class Timeline {
  private int spacing = 2;
  private int sliderSpacing = 3;
  private int sliderHeight = 120;
  private int groupHeight = sliderHeight+40;
  private int groupWidth = 360;
  private int colorBackground = 0xff003652;
  private int colorActiveStep = 0xff00709B;
  private int colorSelected = 0xff9B7900;
  private int colorSelectedActive = 0xffFFC905;
  private int[][] colorMatrix = new int[][] {{colorBackground, colorActiveStep}, {colorSelected, colorSelectedActive}};
  Group group;
  Numberbox numSteps;
  Numberbox duration;
  Button lshift, rshift;
  Toggle loop, smoothend;
  ScrollableList easing;
  TFTimetable fn;

  Slider[] sliders;
  int selectedSlider = 0;
  int animNum;

  Timeline(int animNum) {
    paramLocked = true;

    this.animNum = animNum;

    group = cp5.addGroup("timeline")
      .setPosition(width-accordion.getWidth()-groupWidth-2*margin, margin+groupBarHeight+1)
      .setWidth(groupWidth)
      //.hideBar()
      .setBarHeight(groupBarHeight)
      .setBackgroundHeight(groupHeight)
      .setBackgroundColor(color(0, 100))
      ;

    numSteps = cp5.addNumberbox("tlnumsteps"+animNum)
      .setLabel("Num steps")
      .setPosition(spacing, spacing)
      .setSize(60, 20)
      .setRange(4, 32)
      .setDirection(Controller.HORIZONTAL)
      .setGroup(group)
      ;

    duration = cp5.addNumberbox("duration"+animNum)
      .setLabel("duration")
      .setPosition(numSteps.getPosition()[0]+numSteps.getWidth()+spacing, spacing)
      .setSize(60, 20)
      .setRange(0.5f, 120)
      .setMultiplier(0.05f)
      .setDirection(Controller.HORIZONTAL)
      .setGroup(group)
      ;

    cp5.addScrollableList("tleasing"+animNum)
      .setLabel("easing")
      .setPosition(duration.getPosition()[0]+duration.getWidth()+spacing, spacing)
      .setWidth(80)
      .setBarHeight(20)
      //.setItemHeight(barHeight)
      .onEnter(toFront)
      .onLeave(close)
      .addItems(Animation.interpolationNamesSimp)
      .setGroup(group)
      .close()
      ;

    lshift = cp5.addButton("tllshift"+animNum)
      .setLabel("<<")
      .setPosition(220, spacing)
      .setSize(20, 20)
      .setGroup(group)
      ;

    cp5.addTextlabel("shiftlabel"+animNum)
      .setPosition(lshift.getPosition()[0]+6, spacing+24)
      .setFont(BitFontStandard58)
      .setText("SHIFT")
      .setGroup(group)
      ;

    rshift = cp5.addButton("tlrshift"+animNum)
      .setLabel(">>")
      .setPosition(lshift.getPosition()[0]+lshift.getWidth()+spacing, spacing)
      .setSize(20, 20)
      .setGroup(group)
      ;

    smoothend = cp5.addToggle("smoothend"+animNum)
      .setLabelVisible(false)
      .setPosition(280, spacing)
      .setSize(20, 20)
      .setGroup(group)
      ;
    cp5.addTextlabel("smoothendlabel"+animNum)
      .setPosition(smoothend.getPosition()[0]-15, spacing+24)
      .setText("SMOOTHEND")
      .setFont(BitFontStandard58)
      .setGroup(group)
      ;

    loop = cp5.addToggle("loop"+animNum)
      .setLabelVisible(false)
      .setPosition(330, spacing)
      .setSize(20, 20)
      .setGroup(group)
      ;
    cp5.addTextlabel("looplabel"+animNum)
      .setPosition(loop.getPosition()[0]-2, spacing+24)
      .setFont(BitFontStandard58)
      .setText("LOOP")
      .setGroup(group)
      ;


    sliders = new Slider[32];
    for (int i=0; i<32; i++) {
      sliders[i] = new TimelineSlider(cp5, "tlslider"+i)
        .setGroup(group)
        .setVisible(false)
        ;
    }

    paramLocked = false;
  }


  public void setFunction(TFTimetable fn) {
    this.fn = fn;
    update();
  }

  public TimeFunction getFunction() { 
    return fn;
  }


  public int getAnimNum() { 
    return animNum;
  }


  public void updateTable() {
    int size = (int) numSteps.getValue();
    float[] array = new float[size];
    for (int i=0; i<size; i++) {
      array[i] = sliders[i].getValue();
    }
    fn.setTable(array);
    update();
  }


  public void setTableValue(int idx, float value) {
    fn.setTableValue(idx, value);
    selectedSlider = idx;
  }

  public void hide() {
    group.hide();
  }

  public void show() {
    group.show();
  }


  public void update() {
    // Update all controllers according to the function parameters
    paramLocked = true;

    numSteps.setValue(fn.getTable().length);
    duration.setValue((float) fn.getParam("duration").getValue());
    //easing.setValue((int) fn.getParam("easing").getValue());
    loop.setValue((boolean) fn.getParam("loop").getValue());
    smoothend.setValue((boolean) fn.getParam("smoothend").getValue());

    int numSliders = fn.getTable().length;
    float sliderWidthFloat = ((float) groupWidth - sliderSpacing*(numSliders-1)) / numSliders;
    int sliderMinWidth = floor(sliderWidthFloat);
    int sliderWidth;
    float widthRemains = sliderWidthFloat - sliderMinWidth;
    float widthRemainsCumul = 0f;
    float posX = 0f;
    for (int i=0; i<32; i++) {
      widthRemainsCumul += widthRemains;
      sliderWidth = sliderMinWidth+floor(widthRemainsCumul);
      sliders[i].setPosition(posX, 40)
        .setSize(sliderWidth, sliderHeight)
        .setVisible(i<numSliders)
        .setValue(i<numSliders ? fn.getTable()[i] : 0f)
        ;

      posX += sliderWidth+sliderSpacing;
      if (floor(widthRemainsCumul) > 0)
        widthRemainsCumul -= floor(widthRemainsCumul);
    }

    paramLocked = false;
  }

  public void highlightSliders() {
    int[] step = fn.getActiveStep();
    int n = (int) numSteps.getValue();
    int selected;
    int active;
    for (int i=0; i<n; i++) {
      selected = i==selectedSlider || i==selectedSlider+1 ? 1 : 0;
      active = i==step[0] || i==step[1] ? 1 : 0;
      sliders[i].setColorBackground(colorMatrix[selected][active])
        .setColorForeground(active==1 ? 0xff08a2cf : 0xff00698c);
    }
  }

  public void lshift() {
    int n = (int) numSteps.getValue();
    float first = sliders[0].getValue();
    for (int i=0; i<n-1; i++)
      sliders[i].setValue(sliders[i+1].getValue());
    sliders[n-1].setValue(first);
    updateTable();
  }

  public void rshift() {
    int n = (int) numSteps.getValue();
    float last = sliders[n-1].getValue();
    for (int i=n-1; i>0; i--)
      sliders[i].setValue(sliders[i-1].getValue());
    sliders[0].setValue(last);
    updateTable();
  }


  class TimelineSlider extends Slider {
    public TimelineSlider(ControlP5 theControlP5, String theName) {
      super(theControlP5, theName);
      setRange(-1, 1);
      setSliderMode(Slider.FLEXIBLE);
      setHandleSize(5);
      setNumberOfTickMarks(3);
      snapToTickMarks(false);
      setLabelVisible(false);
    }

    @Override
      protected void onMove( ) {
      if (mousePressed) {
        float f = _myMin + (-(_myControlWindow.getPointer().getY() - (y(_myParent.getAbsolutePosition()) + y(position)) - getHeight())) * _myUnit;
        setValue( PApplet.map(f, 0, 1, _myMinReal, _myMaxReal ) );
      }
    }
  }
}
ControlP5 cp5;
FunctionAccordion accordion;
MyScrollableList partsList;
Button pivotButton;
Textfield animName;
Button prevAnimButton, nextAnimButton;
Timeline timeline;
PFont defaultFont;
int spacing = 4;
int margin = spacing;
int menuBarHeight = 18;
int groupBarHeight = 16;
int keepsOpenAnimNum = -1;
int axeWidth = 72;


class MyScrollableList extends ScrollableList {
  int oldItemHover = -1;

  public MyScrollableList(ControlP5 theControlP5, String theName) { 
    super(theControlP5, theName);
    setType(ScrollableList.LIST);
    setFont(defaultFont);
    setBarHeight(0);
    setBarVisible(false);
  }

  public void highlightPart() {
    if (itemHover != oldItemHover) {
      if (itemHover >= 0 && itemHover < avatar.getPartsList().length) {
        renderer.setSelected(avatar.getPartsList()[itemHover]);
      }
    }
    oldItemHover = itemHover;
  } 

  @Override protected void onEnter() {
    super.onEnter();
    highlightPart();
  }
  @Override protected void onLeave() {
    super.onLeave();
    renderer.setSelected(selected);
  }
  @Override protected void onMove() {
    super.onMove();
    highlightPart();
  }
}



class FunctionAccordion extends Accordion {
  private int accordionWidth = 207;
  
  
  public FunctionAccordion(ControlP5 theControlP5, String theName) { 
    super(theControlP5, theName);
    setWidth(accordionWidth);
    setMinItemHeight(0);
    setCollapseMode(ControlP5.SINGLE);
    spacing = 4;
  }
  
  // Stupid hack to fix a stupid bug
  // (groups used to collapse in wrong order after mouse hovered a scrollable list)
  @Override
  public void controlEvent( ControlEvent theEvent ) {
    super.controlEvent(theEvent);
    String[] m = match(theEvent.getName(), "animation(\\d+)");
    keepsOpenAnimNum = parseInt(m[1]);
    mustUpdateUI = true;
  }
}



public void setupUI() {
  //printArray(PFont.list());
  defaultFont = createFont("DejaVu Sans Mono", 12);

  cp5 = new ControlP5(this);

  partsList = (MyScrollableList) new MyScrollableList(cp5, "partslist")
    .setLabel("parts list")
    .setPosition(margin, margin)
    .setHeight(height-2*margin)
    .setItemHeight(menuBarHeight)
    .hide();
  ;
  

  pivotButton = cp5.addButton("pivotbutton")
    .setPosition(300, 10)
    .setSize(70, 20)
    .setSwitch(true)
    .activateBy(ControlP5.PRESS)
    .setLabel("Set pivot")
    .hide()
    ;

  accordion = new FunctionAccordion(cp5, "accordion");

  // Full Animation selector
  PVector pos = new PVector(-60+width/2, height-margin-24-24);
  animName = cp5.addTextfield("animname")
    //.setLabelVisible(false) // Doesn't work
    .setLabel("")
    .setText("anim0")
    .setPosition(pos.x, pos.y)
    .setSize(120, 24)
    .setFont(defaultFont)
    .setFocus(false)
    .setColor(color(255, 255, 255))
    .setAutoClear(false)
    .hide()
    ;
    
  prevAnimButton = cp5.addButton("prevanim")
    .setLabel("<<")
    .setPosition(pos.x-24-3, pos.y)
    .setSize(24, 24)
    .hide()
    ;

  nextAnimButton = cp5.addButton("nextanim")
    .setLabel(">>")
    .setPosition(pos.x+120+3, pos.y)
    .setSize(24, 24)
    .hide()
    ;
}



public void updateUI() {
  paramLocked = true;

  partsList.open().show();

  // Remove accordion and create new one
  if (accordion != null) {
    cp5.remove("accordion");
    accordion = null;
  }
  accordion = new FunctionAccordion(cp5, "accordion");
  accordion.setPosition(width-accordion.getWidth()-margin, 1);

  PVector pos = new PVector();
  Animation[] animationList = selected.getAnimationList();
  int animNum = 0;
  Group g;

  for (Animation anim : animationList) {
    pos.set(spacing, spacing);

    g = cp5.addGroup("animation"+animNum)
      .setLabel("animation "+animNum)
      //.setFont(defaultFont)
      .setBarHeight(groupBarHeight)
      .setBackgroundColor(color(0, 100))
      ;

    cp5.addScrollableList("function"+animNum)
      .setLabel("function")
      .setFont(defaultFont)
      .setPosition(pos.x, pos.y)
      .setBarHeight(menuBarHeight)
      .setItemHeight(menuBarHeight)
      .onEnter(toFront)
      .onLeave(close)
      .addItems(functionsName)
      .setValue(Arrays.asList(Animation.timeFunctions).indexOf(anim.getFunction().getClass()))
      .moveTo(g)
      .close()
      ;
    pos.add(cp5.getController("function"+animNum).getWidth() + spacing, 0);

    cp5.addScrollableList("axe"+animNum)
      .setLabel("axe")
      .setFont(defaultFont)
      .setPosition(pos.x, pos.y)
      .setWidth(axeWidth)
      .setBarHeight(menuBarHeight)
      .setItemHeight(menuBarHeight)
      .onEnter(toFront)
      .onLeave(close)
      .addItems(Animation.axeNames)
      .setValue(anim.getAxe() >= 0 ? anim.getAxe() : 0)
      .moveTo(g)
      .close()
      ;
    pos.add(cp5.getController("axe"+animNum).getWidth() + spacing, 0);
    
    // Delete animation button
    cp5.addButton("deletebutton"+animNum)
      .setLabel("x")
      .setColorBackground(0xffff0000)
      .setPosition(pos.x, pos.y)
      .setSize(menuBarHeight, menuBarHeight)
      .activateBy(ControlP5.PRESS)
      .setGroup(g)
      ;
    pos.set(spacing, 2*spacing + cp5.getController("axe"+animNum).getHeight());
    pos.add(0.f, spacing);


    // Draw specific parameters
    if (anim.getFunction() instanceof TFTimetable) {
      if (timeline == null) {
        timeline = new Timeline(animNum);
        timeline.setFunction((TFTimetable) anim.getFunction());
      }
      
      cp5.addButton("showtimeline"+animNum)
        .setLabel("Open Timeline")
        .setPosition(pos.x, pos.y)
        .setSize(60, 20)
        .activateBy(ControlP5.PRESS)
        .setGroup(g)
        ;
      pos.add(0.f, 20+spacing);
    } else {
      drawParams(g, animNum, pos);
    }
    pos.add(spacing, spacing);
    
    // Draw Animation general parameters
    cp5.addKnob("animamp"+animNum)
      .setLabel("")
      //.setLabelVisible(false)
      .setPosition(pos.x, pos.y)
      .setRange(0, 500)
      .setResolution(500f)
      .setScrollSensitivity(0.0001f)
      .setValue(anim.getAmp())
      .setRadius(20)
      .setDragDirection(Knob.VERTICAL)
      .setGroup(g)
      ;
    cp5.addTextlabel("amp"+animNum+"label")
        .setPosition(pos.x + 35 + spacing, pos.y + 16)
        .setText("amp".toUpperCase())
        .setGroup(g)
        ;
    pos.set(accordion.getWidth()-82, pos.y);
    
    cp5.addToggle("animinv"+animNum)
        .setLabelVisible(false)
        .setPosition(pos.x, pos.y + 10)
        .setSize(40, 20)
        .setMode(ControlP5.SWITCH)
        .setValue(!anim.getInv())
        .setGroup(g)
        ;
      cp5.addTextlabel("inv"+animNum+"label")
        .setPosition(pos.x + 38 + spacing, pos.y + 15)
        .setText("invert".toUpperCase())
        .setGroup(g)
        ;
    pos.add(0, cp5.getController("animamp"+animNum).getHeight());
    
    pos.set(spacing, pos.y+spacing*2);
    drawBottomButtons(g, animNum, pos);

    g.setBackgroundHeight((int) pos.y);
    accordion.addItem(g);
    animNum++;
  }

  // Add an empty accordion panel for new animations
  pos.set(spacing, spacing);
  g = cp5.addGroup("animation"+animNum)
    .setLabel("animation "+animNum)
    //.setFont(defaultFont)
    .setBarHeight(groupBarHeight)
    .setBackgroundColor(color(0, 100))
    ;

  cp5.addScrollableList("function"+animNum)
    .setLabel("function")
    .setFont(defaultFont)
    .setPosition(pos.x, pos.y)
    .setBarHeight(menuBarHeight)
    .setItemHeight(menuBarHeight)
    .onEnter(toFront)
    .onLeave(close)
    .addItems(functionsName)
    .moveTo(g)
    .close()
    ;
  pos.add(cp5.getController("function"+animNum).getWidth() + spacing, 0);

  cp5.addScrollableList("axe"+animNum)
    .setLabel("axe")
    .setFont(defaultFont)
    .setPosition(pos.x, pos.y)
    .setWidth(axeWidth)
    .setBarHeight(menuBarHeight)
    .setItemHeight(menuBarHeight)
    .onEnter(toFront)
    .onLeave(close)
    .addItems(Animation.axeNames)
    .moveTo(g)
    .close()
    ;
  pos.set(spacing, 2*spacing + cp5.getController("axe"+animNum).getHeight());
  pos.add(0.f, spacing);

  drawBottomButtons(g, animNum, pos);

  g.setBackgroundHeight((int) pos.y);
  accordion.addItem(g);
  
  if (keepsOpenAnimNum >= 0 && keepsOpenAnimNum <= animationList.length) {
    accordion.open(keepsOpenAnimNum);
  } else {
    accordion.open(0);
  }

  paramLocked = false;
}



public void drawParams(Group g, int animNum, PVector pos) {
  Animation anim = selected.getAnimationList()[animNum];
  
  for (TFParam param : anim.getFunction().getParams()) {
    switch (param.type) {
    case TFParam.SLIDER:
      cp5.addSlider(param.name+animNum)
        .setLabel(param.name)
        .setPosition(pos.x, pos.y)
        .setWidth(accordion.getWidth()-40)
        .setHeight(16)
        .setRange(param.min, param.max)
        .setValue((float) param.getValue())
        .setGroup(g)
        ;
      break;
      
    case TFParam.CHECKBOX:
      cp5.addToggle(param.name+animNum)
        .setLabelVisible(false)
        .setPosition(pos.x, pos.y)
        .setSize(20, 20)
        .setValue((boolean) param.getValue())
        .setGroup(g)
        ;
      cp5.addTextlabel(param.name+animNum+"label")
        .setPosition(pos.x + 20 + spacing, pos.y + 4)
        .setText(param.name.toUpperCase())
        .setGroup(g)
        ;
      break;
      
    case TFParam.TOGGLE:
      cp5.addToggle(param.name+animNum)
        .setLabelVisible(false)
        .setPosition(pos.x, pos.y)
        .setSize(40, 20)
        .setMode(ControlP5.SWITCH)
        .setValue((int) param.getValue() == 1 ? true : false)
        .setGroup(g)
        ;
      cp5.addTextlabel(param.name+animNum+"label")
        .setPosition(pos.x + 40 + spacing, pos.y + 4)
        .setText(param.name.toUpperCase())
        .setGroup(g)
        ;
      break;
      
    case TFParam.NUMBERBOX:
      cp5.addNumberbox(param.name+animNum)
        .setLabel("")
        //.setLabelVisible(false) // doesn't work
        .setPosition(pos.x, pos.y)
        .setSize(60, 20)
        .setRange(param.min, param.max)
        .setMultiplier(0.1f) // set the sensitifity of the numberbox
        .setDirection(Controller.HORIZONTAL) // change the control direction to left/right
        .setValue((float) param.getValue())
        .setGroup(g)
        ;
      cp5.addTextlabel(param.name+animNum+"label")
        .setPosition(pos.x + 60 + spacing, pos.y + 4)
        .setText(param.name.toUpperCase() + (param.unit.equals("") ? "" : "  ("+param.unit+")"))
        .setGroup(g)
        ;
      break;
      
    case TFParam.EASING:
      int easingNum = 0;
      for (int i=0; i<Animation.interpolationNamesSimp.length; i++) {
        if (Animation.interpolationNamesSimp[i].equals((String) param.getValue())) {
          easingNum = i;
          break;
        }
      }
      cp5.addScrollableList(param.name+animNum)
        .setLabel("easing function")
        .setPosition(pos.x, pos.y)
        .setBarHeight(menuBarHeight)
        .setItemHeight(menuBarHeight)
        .onEnter(toFront)
        .onLeave(close)
        .addItems(Animation.interpolationNamesSimp)
        .setValue(easingNum)
        .setGroup(g)
        .close()
        ;
      break;
    }
    pos.add(0, cp5.getController(param.name+animNum).getHeight()+spacing);
  }
}



public void drawBottomButtons(Group g, int animNum, PVector pos) {
  boolean bottomButtons = false;

  if (animNum < selected.getAnimationList().length) {
    // Copy animation
    cp5.addButton("copybutton"+animNum)
      .setLabel("copy")
      .setPosition(pos.x, pos.y)
      .setSize(40, 20)
      .activateBy(ControlP5.PRESS)
      .setGroup(g)
      ;
    pos.add(cp5.getController("copybutton"+animNum).getWidth()+spacing, 0);
    
    // Swap position buttons
    cp5.addButton("swapup"+animNum)
      .setLabel("up")
      .setPosition(accordion.getWidth()-42-margin, pos.y)
      .setSize(20, 20)
      .activateBy(ControlP5.PRESS)
      .setGroup(g)
      ;
    if (animNum < 1)
      cp5.getController("swapup"+animNum).hide();
    
    cp5.addButton("swapdown"+animNum)
      .setLabel("dwn")
      .setPosition(accordion.getWidth()-20-margin, pos.y)
      .setSize(20, 20)
      .activateBy(ControlP5.PRESS)
      .setGroup(g)
      ;
    if (animNum == selected.getAnimationList().length-1)
      cp5.getController("swapdown"+animNum).hide();
    
    bottomButtons = true;
  }

  if (animationClipboard != null) {
    // Paste animation
    cp5.addButton("pastebutton"+animNum)
      .setLabel("paste")
      .setPosition(pos.x, pos.y)
      .setSize(42, 20)
      .activateBy(ControlP5.PRESS)
      .setGroup(g)
      ;
    bottomButtons = true;
  }

  if (bottomButtons == true)
    pos.add(0, 20+2*spacing);
}



public void showUI() {
  showUI = true;
  accordion.show();
  partsList.open().show();
  animName.show();
  prevAnimButton.show();
  nextAnimButton.show();
  renderer.setSelected(selected);
}

public void hideUI() {
  showUI = false;
  accordion.hide();
  partsList.hide();
  pivotButton.hide();
  animName.hide();
  prevAnimButton.hide();
  nextAnimButton.hide();
  renderer.setSelected(null);
}



CallbackListener toFront = new CallbackListener() {
  public void controlEvent(CallbackEvent theEvent) {
    theEvent.getController().getParent().bringToFront();
    theEvent.getController().bringToFront();
    ((ScrollableList)theEvent.getController()).open();
  }
};

CallbackListener close = new CallbackListener() {
  public void controlEvent(CallbackEvent theEvent) {
    ((ScrollableList)theEvent.getController()).close();
  }
};
public class WelcomeScreen extends Screen {
  ComplexShape mill;
  float innerRadius;

  public WelcomeScreen() {
    int numWings = floor(random(8, 32));
    innerRadius = numWings * 4;
    float duration = 4f;
    int r1 = floor(random(1, 12));

    // Single wing shape
    float[] verts = new float[] {0f, 10f, 100f, 18f, 106f, 6f, 110f, 0f, 106f, -6f, 100f, -18f, 0f, -10f};
    ComplexShape wing = new ComplexShape();
    DrawablePolygon shape = new DrawablePolygon(verts);
    colorMode(HSB, 1f);
    int c = color(random(1), 0.3f, 1f);
    shape.setColor(red(c), green(c), blue(c), 1f);
    colorMode(RGB, 255);
    wing.addShape(shape);
    TimeFunction stretch = new TFSin(duration*random(0.4f, 2f), 0.3f, map(numWings, 8, 32, 1, 1.5f), 0f);
    wing.addAnimation(new Animation(stretch, Animation.AXE_SX));
    TimeFunction translate = new TFConstant(innerRadius);
    wing.addAnimation(new Animation(translate, Animation.AXE_X));

    mill = new ComplexShape();
    for (int i=0; i<numWings; i++) {
      ComplexShape newWing = wing.copy();
      newWing.setColorMod(random(0.9f, 1.1f), random(0.9f, 1.1f), random(0.9f, 1.1f), 1f);
      newWing.getAnimation(0).setParam("phase", r1*i*360/numWings);
      TimeFunction rotate = new TFConstant((float) i*2/numWings);
      newWing.addAnimation(new Animation(rotate, Animation.AXE_ROT));
      mill.addShape(newWing);
    }

    TimeFunction spin = new TFSpin(0f, duration*random(2.4f, 4f), 1f, 1);
    mill.addAnimation(new Animation(spin, Animation.AXE_ROT));
  }

  @Override
    public void draw() {
    if (avatar != null) {
      showUI();
      currentScreen = mainScreen;
      return;
    }

    background(255);
    
    pushMatrix();
    translate(innerRadius*1.3f, innerRadius*1.3f);
    //translate(width/2, height);
    //scale(1.5);
    mill.updateAnimation(1f/frameRate);
    mill.draw(renderer);
    popMatrix();
    
    fill(127);
    textSize(32);
    text("Press CTRL+o  to load a file", width/3, height/2);
    fill(63);
    textSize(20);
    text("'h' to show help", (width/2) - 80, 50 + height/2);
    text("Ver. "+version, width-110, height-20);
  }

  public @Override
    void mouseClicked(MouseEvent event) {
    selectInput("Select a file", "fileSelected");
    loadScreen = new LoadScreen();
  }

  public @Override
    void keyPressed(KeyEvent event) {
    switch (key) {
    case 'h':  // Help screens
      currentScreen = helpScreen1;
      break;
    case 15:  // CTRL+o, load a new file
      selectInput("Select a file", "fileSelected");
      loadScreen = new LoadScreen();
      break;
    }
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "SgAnimator" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
